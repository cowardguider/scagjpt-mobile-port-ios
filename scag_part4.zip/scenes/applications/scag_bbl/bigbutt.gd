extends Node

var counter = 0

func update_counter():
	%bblcoin.text = tr("APP_SCAG_BBL_COUNTER").format({counter = Util.format_number_with_dots(counter)})

func _process(delta: float) -> void :
	if Globals.is_media_player_showing or Globals.character.state != CharacterWorker.States.MENU_MODE:
		%ScaryahhBBL.stream_paused = true
	else:
		%ScaryahhBBL.stream_paused = false

func _ready() -> void :
	counter = UserConfig.get_value("ScagBBLGame", "counter", 0)
	update_counter()
	$ScaryahhBBL.play()
	var button: Button = %TitleBar.get_node("%CloseButton")
	button.pressed.connect(_on_close_button_pressed)



func touchedBBL() -> void :
	var rng = RandomNumberGenerator.new()
	%Dah.play()
	var random_x: float = rng.randf_range(-6, 12)
	var random_y: float = rng.randf_range(-2, 32)
	%Button.position = Vector2(random_x, random_y)


func _on_close_button_pressed() -> void :
	UserConfig.save_to_file()
	get_parent().close()

func _on_button_pressed() -> void :
	counter += 1
	var side = -1 if Util.random_bool() else 1
	UserConfig.set_value("ScagBBLGame", "counter", counter)
	touchedBBL()
	update_counter()
