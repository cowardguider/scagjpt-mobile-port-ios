extends Node

class SymbolData:
	var node: TextureRect
	var cell_index: int
	var pos_spring: SpringDamper
	var scale_spring: SpringDamper
	var rot_spring: SpringDamper
	var target_scale: Vector2 = Vector2.ONE

@export var buttons: Array[TextureButton] = []
@export var status_label: RichTextLabel
@export var reset_button: Button
@export var close_button: Button

@export_group("Visuals")
@export var texture_x: Texture2D
@export var texture_o: Texture2D

@export_group("Variables I Have Been Playing With")
@export var think_time_min: float = 0.8
@export var think_time_max: float = 1.6
@export var type_speed: float = 30.0
@export var punctuation_delay: float = 0.25

var board: Array[String] = ["", "", "", "", "", "", "", "", ""]
var active_symbols: Array[SymbolData] = []
var is_player_turn: bool = true
var is_game_active: bool = true
var ai: tttAI = tttAI.new()
var wins: int = 0
var winstreak: int = 0
var had_draw: bool = false
var current_status_id: int = 0

@onready var winning_line = $"../VBoxContainer/PanelContainer/WinLine"

func _ready() -> void :
	wins = UserConfig.get_value("TicTacToe", "wins", 0)
	winstreak = UserConfig.get_value("TicTacToe", "winstreak", 0)
	had_draw = UserConfig.get_value("TicTacToe", "had_draw", false)
	update_wins_display()

	for i in range(buttons.size()):
		buttons[i].pressed.connect(_on_cell_clicked.bind(i))

	reset_button.pressed.connect(reset_game)
	close_button.pressed.connect(_on_close_button_pressed)

	reset_game()

func _process(delta: float) -> void :
	var is_in_menu: bool = not Globals.is_media_player_showing and Globals.character.state == CharacterWorker.States.MENU_MODE

	if not is_in_menu:

		$TTTMusic.stream_paused = true
		$TTTWin.stream_paused = true
		$WhistleDown.stream_paused = true
		$ScagTalk.stream_paused = true
	elif is_game_active:

		$TTTMusic.stream_paused = false
		$TTTWin.stream_paused = false
		$WhistleDown.stream_paused = false
		$ScagTalk.stream_paused = false

	if is_game_active and is_player_turn and is_in_menu:
		_process_idle_timer(delta)

	for sym in active_symbols:
		var btn_size = buttons[sym.cell_index].size
		sym.node.pivot_offset = sym.node.size / 2.0
		var base_pos = (btn_size - sym.node.size) / 2.0
		var pos_off = sym.pos_spring.update_spring_damper(Vector2.ZERO, delta)

		sym.node.position = base_pos + pos_off
		sym.node.scale = sym.scale_spring.update_spring_damper(sym.target_scale, delta)
		sym.node.rotation = sym.rot_spring.update_spring_damper(0.0, delta)

func update_wins_display() -> void :
	$"../Wins".visible = true
	$"../Wins".text = tr("APP_TICTACTOE_WINS") + str(wins)

	var streak_node = $"../WinStreak"
	streak_node.visible = true
	streak_node.text = tr("APP_TICTACTOE_WINSTREAK") + str(winstreak) + ("*" if had_draw && winstreak != 0 else "")

	if winstreak >= 20:
		streak_node.modulate = Color.CYAN
	elif winstreak >= 10:
		streak_node.modulate = Color.ORANGE
	elif winstreak >= 5:
		streak_node.modulate = Color.BISQUE
	else:
		streak_node.modulate = Color.WHITE

func set_status_text(new_text: String) -> void :
	if not is_instance_valid(status_label):
		return
	current_status_id += 1
	var this_id: int = current_status_id

	status_label.text = new_text
	status_label.visible_characters = 0

	if has_node("ScagTalk") and not new_text.is_empty():
		$ScagTalk.play()

	var char_delay: float = 1.0 / maxf(type_speed, 1.0)
	var parsed_text: String = status_label.get_parsed_text()
	var total_chars: int = parsed_text.length()

	for i in range(total_chars + 1):
		if current_status_id != this_id:
			return

		while Globals.is_media_player_showing or Globals.character.state != CharacterWorker.States.MENU_MODE:
			if current_status_id != this_id:
				return
			await get_tree().process_frame

		status_label.visible_characters = i

		if i > 0 and i <= total_chars:
			var current_char: String = parsed_text[i - 1]
			var delay: float = char_delay

			if current_char in [".", ",", "!", "?", ";", ":"]:
				delay += punctuation_delay

			await get_tree().create_timer(delay).timeout

		if not is_instance_valid(self) or not is_instance_valid(status_label):
			return

func reset_game() -> void :
	board = ["", "", "", "", "", "", "", "", ""]
	active_symbols.clear()
	is_player_turn = true
	is_game_active = true
	_reset_idle_timer()

	reset_button.visible = false
	winning_line.clear_points()
	winning_line.visible = false

	$TTTMusic.play()

	for i in range(buttons.size()):
		buttons[i].disabled = false
		for child in buttons[i].get_children():
			if child is TextureRect:
				child.queue_free()

	await process_dialogue_event("START_GAME")

func _on_cell_clicked(index: int) -> void :
	if not is_player_turn or not is_game_active or board[index] != "" or Globals.is_media_player_showing or Globals.character.state != CharacterWorker.States.MENU_MODE:
		return

	_reset_idle_timer()
	is_player_turn = false

	var board_before = board.duplicate()
	await make_move(index, "X")

	await get_tree().create_timer(0.2).timeout
	if not is_game_active:
		return

	var player_win_pattern = ai.get_winning_pattern(board, "X")
	if not player_win_pattern.is_empty():
		wins += 1
		winstreak += 1
		had_draw = false

		save_stats()
		update_wins_display()

		$TTTWin.pitch_scale = 0.5
		$TTTWin.play()

		draw_winning_line(player_win_pattern)
		await process_dialogue_event("END_GAME", {"outcome": "PLAYER_WIN", "board_before": board_before})
		return
	elif is_board_full():
		had_draw = true
		save_stats()
		update_wins_display()
		await process_dialogue_event("END_GAME", {"outcome": "DRAW", "board_before": board_before})
		return

	await process_dialogue_event("MOVE", {"who": "X", "index": index, "board_before": board_before})

	play_ai_turn()

func get_random_available_move() -> int:
	var empty_cells: Array[int] = []
	for i in range(board.size()):
		if board[i] == "":
			empty_cells.append(i)
	if empty_cells.is_empty():
		return -1
	return empty_cells.pick_random()

func play_ai_turn() -> void :
	var wait_time = randf_range(think_time_min, think_time_max)
	var timer = 0.0
	while timer < wait_time:
		await get_tree().process_frame
		if not Globals.is_media_player_showing and Globals.character.state == CharacterWorker.States.MENU_MODE:
			timer += get_process_delta_time()

	if not is_instance_valid(self) or not is_game_active:
		return

	while Globals.is_media_player_showing or Globals.character.state != CharacterWorker.States.MENU_MODE:
		if not is_instance_valid(self) or not is_game_active:
			return
		await get_tree().process_frame

	var streak_progress = clamp(float(winstreak) / 20.0, 0.0, 1.0)
	var flub_chance = lerp(0.8, 0.1, streak_progress)

	var ai_move: int = -1
	if randf() < flub_chance:
		ai_move = get_random_available_move()
	else:
		ai_move = ai.compute_ai_move(board)
		if ai_move == -1:
			ai_move = get_random_available_move()

	if ai_move != -1:
		var board_before = board.duplicate()
		await make_move(ai_move, "O")

		var ai_win_pattern = ai.get_winning_pattern(board, "O")
		if not ai_win_pattern.is_empty():
			_record_winstreak_loss()
			winstreak = 0
			had_draw = false

			save_stats()
			update_wins_display()

			$TTTWin.pitch_scale = 1.0
			$TTTWin.play()

			draw_winning_line(ai_win_pattern)
			await process_dialogue_event("END_GAME", {"outcome": "SCAG_WIN", "board_before": board_before})
			return
		elif is_board_full():
			had_draw = true
			save_stats()
			update_wins_display()
			await process_dialogue_event("END_GAME", {"outcome": "DRAW", "board_before": board_before})
			return

		await process_dialogue_event("MOVE", {"who": "O", "index": ai_move, "board_before": board_before})

	is_player_turn = true
	_reset_idle_timer()

func make_move(index: int, whoTurn: String) -> void :
	board[index] = whoTurn
	buttons[index].disabled = true

	$WhistleDown.play()

	var symbol = TextureRect.new()
	symbol.texture = texture_x if whoTurn == "X" else texture_o
	symbol.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	symbol.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	symbol.mouse_filter = Control.MOUSE_FILTER_IGNORE

	symbol.anchor_left = 0.1
	symbol.anchor_top = 0.1
	symbol.anchor_right = 0.9
	symbol.anchor_bottom = 0.9

	buttons[index].add_child(symbol)

	var side = -1 if Util.random_bool() else 1
	var sym_data = SymbolData.new()
	sym_data.node = symbol
	sym_data.cell_index = index
	sym_data.pos_spring = SpringDamper.new(Vector2(0, 45), Vector2(0, -320), 16, 0.25)
	sym_data.scale_spring = SpringDamper.new(Vector2.ZERO, Vector2(1.8, 1.8), 14, 0.3)
	sym_data.rot_spring = SpringDamper.new(0.0, side * randf_range(1.5, 3.5), 12, 0.2)

	active_symbols.append(sym_data)

	await get_tree().create_timer(0.6).timeout

func draw_winning_line(pattern: Array) -> void :
	winning_line.clear_points()

	var first_button = buttons[pattern[0]]
	var last_button = buttons[pattern[2]]

	var start_pos = first_button.get_global_transform() * (first_button.size / 2.0)
	var end_pos = last_button.get_global_transform() * (last_button.size / 2.0)

	winning_line.add_point(winning_line.to_local(start_pos))
	winning_line.add_point(winning_line.to_local(end_pos))
	winning_line.visible = true

	for idx in pattern:
		for sym in active_symbols:
			if sym.cell_index == idx:
				sym.target_scale = Vector2(1.3, 1.3)
				sym.scale_spring.vel += Vector2(2.5, 2.5)
				var side = -1 if Util.random_bool() else 1
				sym.rot_spring.vel += side * randf_range(1.0, 3.0)

func is_board_full() -> bool:
	return not board.has("")

func save_stats() -> void :
	UserConfig.set_value("TicTacToe", "wins", wins)
	UserConfig.set_value("TicTacToe", "winstreak", winstreak)
	UserConfig.set_value("TicTacToe", "had_draw", had_draw)
	UserConfig.save_to_file()

func end_game(message: String) -> void :
	is_game_active = false
	reset_button.visible = true

	$TTTMusic.stop()
	$TTTWin.stop()
	$WhistleDown.stop()
	$ScagTalk.stop()
	for i in range(buttons.size()):
		if board[i] == "":
			buttons[i].disabled = true

func _on_close_button_pressed() -> void :

	$TTTMusic.stop()
	$TTTWin.stop()
	$WhistleDown.stop()
	$ScagTalk.stop()
	save_stats()
	get_parent().close()



var idle_seconds: float = 0.0
var idle_triggered: bool = false
var lost_winstreak_amount: int = 0
var is_first_open: bool = true

const WIN_PATTERNS = [
	[0, 1, 2], [3, 4, 5], [6, 7, 8], 
	[0, 3, 6], [1, 4, 7], [2, 5, 8], 
	[0, 4, 8], [2, 4, 6]
]

var dialogue_pools = {
	"APP_OPEN": [
		"dude hey welcome to tic tac toe", 
		"sup LOSER ready to lose at tic tac toe", 
		"app opened lets do this", 
		"oh you opened this yeah sure lets play"
	], 
	"START_GAME": {
		"normal": [
			"ladies first...", 
			"we shall begin", 
			"you go first i forgot how to play", 
			"yessssss your move", 
		], 
		"high_streak": [
			"alright lets keep going", 
			"so surprisecore you keep wanting to play", 
			"awfully high streak itd be a shame if i", 
			"%d streak... CHOKE CHOKE CHOKE CHOKE CHOKE CHOKE CHOKE CHOKE", 
			"%d it'd be way funnier if it said 0", 
			"sure if you wanna play AGAIN"
		], 
		"huge_streak": [
			"ok now im gonna lock in. you are DONE", 
			"trying to get an even bigger winstreak OK SOOO youre a sweat.", 
			"ok fine i literally can't NOT playmaxx but you gotta go outside so bad"
		], 
		"lost_streak": [
			"haha streak loser baby says what. sorry i gotta make fun of you for that", 
			"ok tbh gotta respect the determination sure", 
			"yea sure if you wanna try getting the streak back"
		]
	}, 
	"PLAYER_OPTIMAL": [
		"yea thats what i woulda did", 
		"smart move", 
		"yeahhhh i knew youd do that", 
		"so psychicpilled the way i saw that coming"
	], 
	"PLAYER_NEUTRAL": [
		"fair enough", 
		"okay standard move", 
		"ok yeah ive seen that before", 
		"lowkey seen better moves but sure", 
		"lowkey seen worse moves but sure", 
		"yeah thats definitely a move you can make", 
		"the ticmaxxer", 
		"fair play"
	], 
	"PLAYER_SUBOPTIMAL": [
		"lol...", 
		"boldcore", 
		"lmao did you misclick or something", 
		"dude.", 
		"cringe"
	], 
	"SCAG_OPTIMAL": [
		"absolute thinkmaxxer right here", 
		"ok dude watch the strat", 
		"actually magnuscore rn", 
		"scagtastic strat going on rn just you watch", 
		"im the galaxy brain reddit image dude HOLY", 
		"i know exactly where you go RIGHT HERE you go here", 
		"im so locked in"
	], 
	"SCAG_NEUTRAL": [
		"im setting something great up rn", 
		"placemaxxing", 
		"ok watch in 7 turns youll be checkmatefilled", 
		"yeah i dont have a ton of options tbh good enough", 
		"im coinmaxxing rn", 
		"lala"
	], 
	"SCAG_SUBOPTIMAL": [
		"ok WAIT that was a misinput let me go again", 
		"ok chat lemme clipfarm", 
		"ok dude ACTUALLY watch the strat.", 
		"uhhhhhh sure here works idk", 
		"ugh im bored youre boring im just gonna put this wherever"
	], 
	"PLAYER_BLOCK_GAP": [
		"ugh rude", 
		"hey i was gonna use that", 
		"fine ruinmaxx my setup why dont you", 
		"nobody likes you", 
		"dude uncool", 
		"boooo you ruin all my fun", 
		"rigged"
	], 
	"SCAG_BLOCK_GAP": [
		"lol i saw that", 
		"blocked. try harder.", 
		"not blind IDIOT", 
		"nah", 
		"gapmaxxing. NOT!", 
		"im so locked in dont even try"
	], 
	"PLAYER_FORK_WIN": [
		"okay dude whats the point in flexing", 
		"okay doublefilled move over here...", 
		"overkill", 
	], 
	"SCAG_FORK_WIN": [
		"that was awesome", 
		"had 2 ways to win you had 2 looooosers", 
		"dude you got megaowned", 
	], 
	"SCAG_WIN_BLUNDER": [
		"DUDE YOU LEFT THAT SO OPEN YOU ARE SO DUMB", 
		"how did you miss that", 
		"thanks for letting me win", 
	], 
	"SCAG_WIN": {
		"low": [
			"I WIN LOSER", 
			"GG EZ", 
			"better luck next time", 
			"im literally the best and everyone loves me", 
			"💙 W SCAG"
		], 
		"high": [
			"byeee byeeee streak", 
			"Scagalicious", 
			"oh my god dude FINALLY", 
			"I WIN LOSER", 
			"GG EZ", 
			"better luck next time", 
			"im literally the best and everyone loves me", 
			"💙 W SCAG"
		], 
		"huge": [
			"byeee byeeee streak PLEASE go outside now PLEASE i beg of you", 
			"byeee byeeee streak", 
			"Scagalicious", 
			"oh my god dude FINALLY", 
			"I WIN LOSER", 
			"GG EZ", 
			"better luck next time", 
			"im literally the best and everyone loves me", 
			"💙 W SCAG"
		]
	}, 
	"PLAYER_WIN": {
		"low": [
			"sure you win...", 
			"ok yeah sure", 
			"that was rude", 
			"didnt have to do that but whatever", 
			"meanfilled", 
			"you probably cheated", 
		], 
		"high": [
			"wow look you are soooo %d winscore", 
			"yeah that makes sense", 
			"ok lets do it again but CLOSEMAXX CHEAT ENGINE", 
			"you definitely cheated"
		], 
		"huge": [
			"ok log off magnus", 
			"ok well now i know youre cheating", 
			"ugh watchdog report admins banmaxx this guy", 
			"whaaaaaatever", 
			"loooooooooooooooooser"
		]
	}, 
	"DRAW": {
		"default": [
			"nobody wins.", 
			"ok nobody wins.", 
			"a tie? boooooooring."
		]
	}, 
	"IDLE": [
		"hellooo? any day now.", 
		"lalalala i got all day", 
		"dude you are playing a game rn WAKE UP", 
		"lamefilled wake up dude", 
		"sleepcore"
	]
}

func process_dialogue_event(event_type: String, data: Dictionary = {}) -> void :
	var line: String = ""

	match event_type:
		"START_GAME":
			if is_first_open:
				is_first_open = false
				line = dialogue_pools["APP_OPEN"].pick_random()
			else:
				if lost_winstreak_amount > 0:
					line = _format_dialogue(dialogue_pools["START_GAME"]["lost_streak"].pick_random(), lost_winstreak_amount)
					lost_winstreak_amount = 0
				elif winstreak >= 20:
					line = _format_dialogue(dialogue_pools["START_GAME"]["huge_streak"].pick_random(), winstreak)
				elif winstreak >= 5:
					line = _format_dialogue(dialogue_pools["START_GAME"]["high_streak"].pick_random(), winstreak)
				else:
					line = dialogue_pools["START_GAME"]["normal"].pick_random()

		"MOVE":
			var who: String = data.get("who", "X")
			var index: int = data.get("index", -1)
			var board_before: Array = data.get("board_before", [])
			var opponent: String = "O" if who == "X" else "X"

			if _is_threat_block(board_before, index, opponent):
				if who == "X":
					line = dialogue_pools["PLAYER_BLOCK_GAP"].pick_random()
				else:
					line = dialogue_pools["SCAG_BLOCK_GAP"].pick_random()
			elif board.count(who) <= 1:
				if who == "X":
					line = dialogue_pools["PLAYER_NEUTRAL"].pick_random()
				else:
					line = dialogue_pools["SCAG_NEUTRAL"].pick_random()
			else:
				var best_move = ai.compute_ai_move(board_before)
				var is_optimal = (index == best_move) or (best_move == -1)
				var is_suboptimal = _is_suboptimal_move(board_before, index, who)

				if who == "X":
					if is_optimal:
						line = dialogue_pools["PLAYER_OPTIMAL"].pick_random()
					elif is_suboptimal:
						line = dialogue_pools["PLAYER_SUBOPTIMAL"].pick_random()
					else:
						line = dialogue_pools["PLAYER_NEUTRAL"].pick_random()
				else:
					if is_optimal:
						line = dialogue_pools["SCAG_OPTIMAL"].pick_random()
					elif is_suboptimal:
						line = dialogue_pools["SCAG_SUBOPTIMAL"].pick_random()
					else:
						line = dialogue_pools["SCAG_NEUTRAL"].pick_random()

		"END_GAME":
			end_game("")
			var outcome: String = data.get("outcome", "")
			var board_before: Array = data.get("board_before", [])

			if outcome == "SCAG_WIN":
				Globals.ragebait = Time.get_ticks_msec() / 1000.0

				if _count_winning_threats(board_before, "O") >= 2:
					line = dialogue_pools["SCAG_FORK_WIN"].pick_random()
				elif _was_missed_block_win(board_before, "O"):
					line = dialogue_pools["SCAG_WIN_BLUNDER"].pick_random()
				else:
					if lost_winstreak_amount >= 20:
						line = _format_dialogue(dialogue_pools["SCAG_WIN"]["huge"].pick_random(), lost_winstreak_amount)
					elif lost_winstreak_amount >= 5:
						line = _format_dialogue(dialogue_pools["SCAG_WIN"]["high"].pick_random(), lost_winstreak_amount)
					else:
						line = dialogue_pools["SCAG_WIN"]["low"].pick_random()

			elif outcome == "PLAYER_WIN":
				if _count_winning_threats(board_before, "X") >= 2:
					line = dialogue_pools["PLAYER_FORK_WIN"].pick_random()
				else:
					if winstreak >= 20:
						line = _format_dialogue(dialogue_pools["PLAYER_WIN"]["huge"].pick_random(), winstreak)
					elif winstreak >= 5:
						line = _format_dialogue(dialogue_pools["PLAYER_WIN"]["high"].pick_random(), winstreak)
					else:
						line = dialogue_pools["PLAYER_WIN"]["low"].pick_random()

			elif outcome == "DRAW":
				line = dialogue_pools["DRAW"]["default"].pick_random()
				line += "\n[wave][color=white](Streak remains... but you better win next time.)[/color][/wave]"

	await set_status_text(line)

func _format_dialogue(template: String, value: int) -> String:
	if "%d" in template:
		return template % value
	return template

func _reset_idle_timer() -> void :
	idle_seconds = 0.0
	idle_triggered = false

func _process_idle_timer(delta: float) -> void :
	if idle_triggered:
		return
	idle_seconds += delta
	if idle_seconds >= 15.0:
		idle_triggered = true
		set_status_text(dialogue_pools["IDLE"].pick_random())


func _record_winstreak_loss() -> void :
	if winstreak > 0:
		lost_winstreak_amount = winstreak

func _is_threat_block(board_state: Array, move_idx: int, threat_owner: String) -> bool:
	for pattern in WIN_PATTERNS:
		if move_idx in pattern:
			var owner_count = 0
			var empty_count = 0
			for idx in pattern:
				if board_state[idx] == threat_owner:
					owner_count += 1
				elif board_state[idx] == "":
					empty_count += 1
			if owner_count == 2 and empty_count == 1:
				return true
	return false

func _count_winning_threats(board_state: Array, player: String) -> int:
	var threats = 0
	for pattern in WIN_PATTERNS:
		var count_p = 0
		var count_empty = 0
		for idx in pattern:
			if board_state[idx] == player:
				count_p += 1
			elif board_state[idx] == "":
				count_empty += 1
		if count_p == 2 and count_empty == 1:
			threats += 1
	return threats

func _is_suboptimal_move(board_before: Array, move_idx: int, player: String) -> bool:
	var opponent = "O" if player == "X" else "X"

	for pattern in WIN_PATTERNS:
		var count_p = 0
		var count_empty = 0
		var win_idx = -1
		for idx in pattern:
			if board_before[idx] == player:
				count_p += 1
			elif board_before[idx] == "":
				count_empty += 1
				win_idx = idx
		if count_p == 2 and count_empty == 1 and move_idx != win_idx:
			return true

	for pattern in WIN_PATTERNS:
		var count_opp = 0
		var count_empty = 0
		var block_idx = -1
		for idx in pattern:
			if board_before[idx] == opponent:
				count_opp += 1
			elif board_before[idx] == "":
				count_empty += 1
				block_idx = idx
		if count_opp == 2 and count_empty == 1 and move_idx != block_idx:
			return true

	return false

func _was_missed_block_win(board_before_win: Array, winner: String) -> bool:
	for pattern in WIN_PATTERNS:
		var count_winner = 0
		var count_empty = 0
		for idx in pattern:
			if board_before_win[idx] == winner:
				count_winner += 1
			elif board_before_win[idx] == "":
				count_empty += 1
		if count_winner == 2 and count_empty == 1:
			return true
	return false
