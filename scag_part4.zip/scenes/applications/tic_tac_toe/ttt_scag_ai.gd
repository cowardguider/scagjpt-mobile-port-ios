class_name tttAI
extends RefCounted




const WIN_PATTERNS = [
	[0, 1, 2], [3, 4, 5], [6, 7, 8], 
	[0, 3, 6], [1, 4, 7], [2, 5, 8], 
	[0, 4, 8], [2, 4, 6]
]

func compute_ai_move(board: Array[String]) -> int:
	var available: Array[int] = []
	for i in range(9):
		if board[i] == "":
			available.append(i)

	if available.is_empty():
		return -1

	if randf() < 0.5:
		return available.pick_random()

	return compute_best_move(board, available)

func compute_best_move(board: Array[String], available: Array[int]) -> int:
	for i in available:
		if simulates_win(board, i, "O"):
			return i

	for i in available:
		if simulates_win(board, i, "X"):
			return i

	if board[4] == "":
		return 4

	return available.pick_random()

func simulates_win(board: Array[String], index: int, whoTurn: String) -> bool:
	board[index] = whoTurn
	var wins: bool = not get_winning_pattern(board, whoTurn).is_empty()
	board[index] = ""
	return wins

func get_winning_pattern(board: Array[String], whoTurn: String) -> Array:
	for pattern in WIN_PATTERNS:
		if board[pattern[0]] == whoTurn and board[pattern[1]] == whoTurn and board[pattern[2]] == whoTurn:
			return pattern
	return []
