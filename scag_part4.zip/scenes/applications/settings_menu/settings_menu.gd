extends Node

const SETTING_ENUM = preload("uid://doynt2e3jk864")
const SETTING_BOOLEAN = preload("uid://r2bkf1mtdrcf")
const SETTING_SLIDER = preload("uid://ctup35qp8471d")

@onready var settings_categories: HBoxContainer = %SettingCategories
@onready var shown_settings: VBoxContainer = %ShownSettings

var selected_category: int = 0
var _existing_ui: Array[Control] = []

func _ready() -> void :
	print("Show settings UI")
	_draw()

	var children_categories = settings_categories.get_children() as Array[Button]
	for button: Button in children_categories:
		var prefix = button.name.left(1).to_int()
		button.pressed.connect(_select_category.bind(prefix))

func _select_category(category: int = 0):
	if selected_category == category:
		return
	selected_category = category
	_draw()

func _draw() -> void :
	for ui in _existing_ui:
		ui.queue_free()
	_existing_ui.clear()

	for setting: SettingData in GameSettings.ClassedSettings:
		if setting.category == selected_category:
			if setting is SettingDataBoolean:
				var ui: SettingBooleanContainer = SETTING_BOOLEAN.instantiate()
				ui.set_deferred(&"setting_name", setting.id)
				ui.set_deferred(&"setting_value", setting.boolean_value)
				shown_settings.add_child(ui)
				_existing_ui.append(ui)
			elif setting is SettingDataSlider:
				var ui: SettingSliderContainer = SETTING_SLIDER.instantiate()
				print("New setting: %s - %s" % [setting.id, setting.slider_value])
				ui.set_deferred(&"setting_name", setting.id)
				ui.set_deferred(&"setting_value", setting.slider_value)
				ui.set_deferred(&"minimum_value", setting.slider_min)
				ui.set_deferred(&"maximum_value", setting.slider_max)
				ui.set_deferred(&"step_value", setting.slider_step)
				ui.call_deferred(&"_update", setting.slider_value)
				shown_settings.add_child(ui)
				_existing_ui.append(ui)
			elif setting is SettingDataEnum:
				var ui: SettingEnumContainer = SETTING_ENUM.instantiate()
				ui.set_deferred(&"setting_name", setting.id)
				ui.set_deferred(&"setting_options", setting.enum_arguments)
				ui.set_deferred(&"setting_value", setting.enum_value)
				shown_settings.add_child(ui)
				_existing_ui.append(ui)

func _on_close_button_pressed() -> void :
	get_parent().close()
