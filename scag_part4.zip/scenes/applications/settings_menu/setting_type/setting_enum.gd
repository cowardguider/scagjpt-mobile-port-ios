@tool
class_name SettingEnumContainer
extends VBoxContainer

@onready var label_ui: Label = $MarginContainer / HBoxContainer / Label
@onready var option_ui: OptionButton = $MarginContainer / HBoxContainer / OptionButton

@export var setting_name: String = "My Setting":
	set(value):
		setting_name = value
		label_ui.text = tr("SETTING_" + setting_name)
		var hover_tooltip: HoverTooltipComponent = get_node_or_null("%HoverTooltipComponent")
		if hover_tooltip and !Util.tr_key_exists("SETTING_DESCRIPTION_" + setting_name):
			hover_tooltip.queue_free()
		elif hover_tooltip:
			hover_tooltip.hint = tr("SETTING_DESCRIPTION_" + setting_name)

@export var setting_options: Array[String]:
	set(value):
		setting_options = value
		option_ui.clear()

		var i = 0
		for opt in value:
			option_ui.add_item(opt, i)
			i += 1

@export var setting_value: int:
	set(value):
		setting_value = value
		option_ui.select(value)
		GameSettings.set_setting_and_update(setting_name, setting_value)

func _ready() -> void :
	option_ui.item_selected.connect(_update)

func _update(value: int) -> void :
	setting_value = value
