@tool
class_name SettingBooleanContainer
extends VBoxContainer

@onready var check_box: AnimatedCheckButton = $MarginContainer / HBoxContainer / CheckBox
@onready var label_ui: Label = $MarginContainer / HBoxContainer / Label

@export var setting_name: String = "My Setting":
	set(value):
		setting_name = value
		label_ui.text = tr("SETTING_" + setting_name)
		var hover_tooltip: HoverTooltipComponent = get_node_or_null("%HoverTooltipComponent")
		if hover_tooltip and !Util.tr_key_exists("SETTING_DESCRIPTION_" + setting_name):
			hover_tooltip.queue_free()
		elif hover_tooltip:
			hover_tooltip.hint = tr("SETTING_DESCRIPTION_" + setting_name)

@export var setting_value: bool = false:
	set(value):
		setting_value = value
		check_box.button_pressed = value

func _ready() -> void :
	check_box.pressed.connect(_update)

func _update() -> void :
	setting_value = check_box.button_pressed
	GameSettings.set_setting_and_update(setting_name, setting_value)
