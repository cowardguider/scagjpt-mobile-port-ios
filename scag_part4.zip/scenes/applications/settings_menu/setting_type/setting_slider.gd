@tool
class_name SettingSliderContainer
extends VBoxContainer

signal updated(value: float)

@onready var slider_ui: HSlider = %Slider
@onready var value_ui: Label = %Value
@onready var label_ui: Label = %Label

var locked = false

@export var setting_name: String = "My Setting":
	set(value):
		setting_name = value
		label_ui.text = tr("SETTING_" + setting_name)
		var hover_tooltip: HoverTooltipComponent = get_node_or_null("%HoverTooltipComponent")
		if hover_tooltip and !Util.tr_key_exists("SETTING_DESCRIPTION_" + setting_name):
			hover_tooltip.queue_free()
		elif hover_tooltip:
			hover_tooltip.hint = tr("SETTING_DESCRIPTION_" + setting_name)

@export var setting_value: float = 0.0:
	set(value):
		setting_value = value

@export var minimum_value: float = 0.0:
	set(value):
		minimum_value = value
		slider_ui.min_value = minimum_value

@export var maximum_value: float = 100.0:
	set(value):
		maximum_value = value
		slider_ui.max_value = maximum_value

@export var step_value: float = 1.0:
	set(value):
		step_value = value
		slider_ui.step = step_value

func _ready() -> void :
	slider_ui.value_changed.connect(_update)

func _update(value: float) -> void :
	if locked: return
	locked = true
	setting_value = value
	slider_ui.value = value
	print("Setting %s, set to %s" % [setting_name, setting_value])
	value_ui.text = str(value)
	GameSettings.set_setting_and_update(setting_name, setting_value)
	locked = false
