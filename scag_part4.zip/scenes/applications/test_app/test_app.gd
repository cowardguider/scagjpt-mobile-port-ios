extends Node

var counter = 0
var scale_spring: SpringDamper
var rot_spring: SpringDamper
var counter_pos_spring: SpringDamper
var counter_rot_spring: SpringDamper
var disclaimer_spring: SpringDamper
var window_spring: SpringDamper

func update_counter():
	%CounterLabel.text = tr("APP_SQUARE_CIRCLE_SHOW_GAME_COUNTER").format({counter = Util.format_number_with_dots(counter)})

func _ready() -> void :
	scale_spring = SpringDamper.new(Vector2.ONE, Vector2.ZERO, 14, 0.3)
	rot_spring = SpringDamper.new(0, 0, 12, 0.15)
	counter_pos_spring = SpringDamper.new(Vector2.ZERO, Vector2.ZERO, 18, 0.3)
	counter_rot_spring = SpringDamper.new(0, 0, 18, 0.15)
	disclaimer_spring = SpringDamper.new(Vector2.ZERO, Vector2.ZERO, 12, 0.1)
	window_spring = SpringDamper.new(Vector2.ZERO, Vector2.ZERO, 8, 0.5)
	counter = UserConfig.get_value("SquareAndCircleGame", "counter", 0)
	update_counter()
	var button: Button = %TitleBar.get_node("%CloseButton")
	button.pressed.connect(_on_close_button_pressed)

func _process(delta: float) -> void :
	%Button.offset_transform_scale = scale_spring.update_spring_damper(Vector2.ONE, delta)
	%Button.offset_transform_rotation = rot_spring.update_spring_damper(0, delta)
	%CounterLabel.offset_transform_position = counter_pos_spring.update_spring_damper(Vector2.ZERO, delta)
	%CounterLabel.offset_transform_rotation = counter_rot_spring.update_spring_damper(0, delta)
	%Disclaimer.offset_transform_scale = disclaimer_spring.update_spring_damper(Vector2.ONE, delta)
	get_parent().offset_transform_position = window_spring.update_spring_damper(Vector2.ZERO, delta)

func _on_close_button_pressed() -> void :

	UserConfig.save_to_file()
	get_parent().close()

func _on_button_pressed() -> void :
	counter += 1
	var side = -1 if Util.random_bool() else 1
	scale_spring.vel -= Vector2(1.2, 1.2)
	rot_spring.vel += side * randf_range(1, 5)
	counter_pos_spring.vel += Vector2(
		side * randf_range(30, 90), 
		500
	)
	counter_rot_spring.vel += side * randf_range(1, 3)
	disclaimer_spring.vel += Vector2(1.5, 1.5)
	window_spring.vel += Vector2(
		(-1 if Util.random_bool() else 1) * randf_range(20, 40), 
		(-1 if Util.random_bool() else 1) * randf_range(20, 40)
	)
	UserConfig.set_value("SquareAndCircleGame", "counter", counter)
	update_counter()
	var clone: AudioStreamPlayer = $Dah.duplicate()
	add_child(clone)
	clone.play()
	await clone.finished
	clone.queue_free()
