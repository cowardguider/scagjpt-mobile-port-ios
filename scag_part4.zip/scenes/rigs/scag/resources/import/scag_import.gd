@tool
extends EditorScenePostImport

func _post_import(scene: Node) -> Object:
	if scene.get_node("AnimationPlayer"):
		mark_anims_constant(scene.get_node("AnimationPlayer"))
	return scene

func mark_anims_constant(animationPlayer: AnimationPlayer):
	for animationName in animationPlayer.get_animation_list():
		var animation = animationPlayer.get_animation(animationName)
		for trackIndex in animation.get_track_count():
			var trackPath = animation.track_get_path(trackIndex)




			animation.track_set_interpolation_type(trackIndex, Animation.INTERPOLATION_NEAREST)
