@tool
extends Skeleton3D



var faceMesh: MeshInstance3D
var faceMaterial: ShaderMaterial

func _ready() -> void :
	faceMesh = get_node("Face_001")
	if !faceMesh:
		push_warning("No mesh found for scag face!")
		set_process(false)
		return
	faceMaterial = faceMesh.mesh.surface_get_material(0)

	if !faceMaterial:
		push_warning("No material found for scag face!")
		set_process(false)
		return




func _process(_delta: float) -> void :
	var boneIndex = find_bone("FaceBone")
	if !boneIndex:
		push_warning("Scag face bone not found. Stopping process.")
		set_process(false)
		return
	var pos = get_bone_pose(boneIndex)


	var offset = (pos.origin.x - 1) * 100 * 0.03333333333

	faceMaterial.set_shader_parameter("scag_face_offset", offset)
