shader_type spatial;
render_mode blend_mix, depth_draw_opaque;

group_uniforms Shader.Albedo;
uniform vec4 albedo_color : source_color = vec4(1.0);
uniform sampler2D albedo_texture;

group_uniforms Shader.Alpha;
uniform vec4 alpha_color : source_color = vec4(1.0);
uniform sampler2D alpha_texture;

group_uniforms Shader.Light;
uniform bool use_stepped = true;
uniform float steps = 3.0;
uniform float step_smoothness = 0.3;

uniform vec4 shadow_tint : source_color = vec4(0.0, 0.0, 0.0, 1.0);
uniform float shadow_tint_amount = 0.4;

group_uniforms Shader.Emission;
uniform vec4 emission_color : source_color = vec4(1.0);
uniform float emission_energy = 1.0;
uniform sampler2D emission_texture;

group_uniforms Shader.Specular;
uniform float specular = 0.0;

group_uniforms Shader.Normal;
uniform float normal_strength = 0.0;
uniform sampler2D normal_texture;

group_uniforms Shader.Rim_REPLACED;
uniform float fresnel_mult = 1.0;
uniform float power_value = 4.0;
uniform float final_mult = 1.0;

uniform vec3 rim_emission_tint = vec3(0.768, 0.823, 1.0);
uniform float rim_emission_strength = 0.0;
uniform float rim_saturation_boost = 2.0;
uniform vec3 rim_direction = vec3(7.9, -0.01, -3.88);
uniform float rim_direction_strength = 1.8;
uniform float rim_contrast = 1.0;

group_uniforms Shader.Pattern;
uniform bool use_pattern = true;
uniform sampler2D pattern_texture;

uniform int pattern_uv_mode = 2;
uniform float pattern_tiling = 32.0;
uniform float pattern_amount = 0.5;
uniform float pattern_smoothness = 0.5;
uniform float pattern_blend = 0.2;

varying vec4 node_position;

vec2 get_pattern_uv(vec2 uv, vec2 screen_uv) {
    vec2 local_screen = (screen_uv * 2.0 - 1.0) * node_position.w - node_position.xy;
    return mix(uv, mix(screen_uv, local_screen, float(pattern_uv_mode == 2)), float(pattern_uv_mode > 0));
}

float shape_value(float value, vec2 uv, vec2 screen_size) {
    float aspect = screen_size.y / screen_size.x;
    vec2 p_uv = uv * pattern_tiling * vec2(1.0, aspect);

    float pat = texture(pattern_texture, p_uv).r;
    float v = value + pattern_amount;

    return smoothstep(pat - pattern_smoothness, pat + pattern_smoothness, v);
}

void vertex() {
    node_position = PROJECTION_MATRIX * vec4(NODE_POSITION_VIEW, 1.0);
}

void fragment() {
    vec4 albedo = texture(albedo_texture, UV) * albedo_color;
    vec4 alpha_tex = texture(alpha_texture, UV);
    vec4 emission_tex = texture(emission_texture, UV);

    ALBEDO = albedo.rgb;
    ALPHA_SCISSOR_THRESHOLD = 0.5;
    ALPHA = alpha_tex.a * alpha_color.a;

    EMISSION = emission_tex.rgb * emission_color.rgb * emission_energy;

    if (normal_strength > 0.001) {
        vec3 nm = texture(normal_texture, UV).rgb;
        NORMAL_MAP = mix(vec3(0.5, 0.5, 1.0), nm, normal_strength);
    }

    SPECULAR = specular;
}

void light() {
    vec3 n = normalize(NORMAL);
    vec3 l = normalize(LIGHT);
    vec3 V = normalize(VIEW);
    vec3 rim_dir = normalize(rim_direction);

    float ndotl = max(dot(n, l), 0.0) * ATTENUATION;
    float light = ndotl;

    if (use_stepped) {
        float lm = light * steps;
        float sb = floor(lm);
        float lf = lm - sb;
        lf = smoothstep(0.5 - step_smoothness, 0.5 + step_smoothness, lf);
        light = (sb + lf) / steps;
    }

    if (use_pattern) {
        vec2 p_uv = get_pattern_uv(UV, SCREEN_UV);
        float pl = shape_value(light, p_uv, VIEWPORT_SIZE);
        light = mix(light, max(pl, 0.05), pattern_blend);
    }

    vec3 diffuse = vec3(light) * (LIGHT_COLOR / PI);
    diffuse = mix(shadow_tint.rgb * shadow_tint_amount, diffuse, light);

    float fres = 1.0 - dot(n, V);
    fres = max(fres, 0.0);

    float dir_mask = max(dot(n, rim_dir), 0.0);

    float rim = fres * fresnel_mult * dir_mask * rim_direction_strength;

    rim = pow(rim, power_value);
    rim *= final_mult;

    rim = (rim - 0.5) * rim_contrast + 0.5;
    rim = clamp(rim, 0.0, 1.0);

    vec3 rim_color = diffuse + rim_emission_tint * rim_emission_strength;

    float luma = dot(rim_color, vec3(0.61, 0.831, 0.04));
    rim_color = mix(vec3(luma), rim_color, rim_saturation_boost);

    diffuse += rim_color * rim;

    DIFFUSE_LIGHT += diffuse;

    float spec_term = exp2(log2(max(light, 0.0)) * 50.0);
    SPECULAR_LIGHT += vec3(spec_term) * specular;
}
