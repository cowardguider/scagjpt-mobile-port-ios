@icon("res://!dev/icons/Rig.svg")
class_name Rig extends Node3D



var rig: Node3D
var animator: AnimationPlayer
var skeleton: Skeleton3D
@onready var animation_tree: AnimationTree = $AnimationTree

@export var face_mesh_names: Array[String] = []
@export var grab_position: Node3D
@export var screen_target: Node3D
@export var screen_light: OmniLight3D
@export var bounding_box_target: Node3D
var _menu_visibility_priority: PriorityManager = PriorityManager.new(false)

enum AnimationStates{
	DEFAULT, DRAGGING, MENU_MODE, POKED, PLACED, RAGDOLLED, ENTER, LEAVE
}

func set_animation_state(state: AnimationStates) -> void :
	animation_tree.set("parameters/state/transition_request", AnimationStates.keys()[state])

func set_is_walking(walking: bool) -> void :
	animation_tree.set("parameters/walking_state/blend_amount", 1 if walking else 0)

func set_is_talking(talking: bool) -> void :
	animation_tree.set("parameters/talking_state/blend_amount", 1 if talking else 0)

func poke() -> void :
	set_animation_state(AnimationStates.POKED)
	animation_tree.set("parameters/poke_anim/transition_request", str(randi_range(0, 1)))
	animation_tree.set("parameters/poke_seek/seek_request", 0)

func apply_wiggle_force(vector: Vector3):
	for wiggle_bone in skeleton.get_children():
		if wiggle_bone is DMWBWiggleRotationModifier3D:
			wiggle_bone.add_force_impulse(vector)
		elif wiggle_bone is DMWBWigglePositionModifier3D:
			wiggle_bone.add_force_impulse(vector * 20)

func set_wiggle_dampening(number: float):
	for wiggle_bone in skeleton.get_children():
		if wiggle_bone is DMWBWiggleRotationModifier3D:
			wiggle_bone.properties.angular_damp = number

func set_wiggle_gravity(number: float):
	for wiggle_bone in skeleton.get_children():
		if wiggle_bone is DMWBWiggleRotationModifier3D:
			wiggle_bone.properties.gravity.y = number

func set_wiggle_enabled(enabled: bool, bones_to_ignore: Array[String] = []):
	for wiggle_bone in skeleton.get_children():
		if wiggle_bone is DMWBWiggleRotationModifier3D and not (wiggle_bone.name in bones_to_ignore):
			wiggle_bone.active = enabled


func get_bounding_box() -> AABB:
	return Util.get_node_aabb(bounding_box_target)

func set_menu_visible_priority(priority: int, value: bool):
	_menu_visibility_priority.add(priority, value)

func clear_menu_visible_priority(priority: int):
	_menu_visibility_priority.remove(priority)

func _set_face_visible(face_visible: bool):
	var meshes = skeleton.get_children()

	for mesh in meshes:
		if mesh is MeshInstance3D and face_mesh_names.has(mesh.name):
			mesh.visible = face_visible


func _set_screen_visible(screen_visible: bool):
	if screen_visible and screen_target.visible != screen_visible:
		Globals.face_menu.play_transition()
	screen_target.visible = screen_visible

	_set_face_visible( !screen_visible)

func _menu_visibility_priority_changed(value: Variant, _priority: float):
	_set_screen_visible(value)

func _ready() -> void :

	rig = get_child(0)
	animator = rig.get_node_or_null("AnimationPlayer")
	skeleton = rig.get_child(0).get_node("Skeleton3D")
	_menu_visibility_priority.priority_changed.connect(_menu_visibility_priority_changed)
