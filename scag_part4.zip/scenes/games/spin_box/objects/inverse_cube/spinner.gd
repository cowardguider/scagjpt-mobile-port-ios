extends Node3D

var cubey: RigidBody3D
const MOVE_SPEED = 3000
const DRAG_SPEED = 2000

func _ready() -> void :
	cubey = get_node("Cube")
	print(cubey)

var holding = false
func _input(event: InputEvent) -> void :
	if event is InputEventMouseMotion and holding:
		cubey.angular_velocity += Vector3(deg_to_rad(event.position.x), deg_to_rad(event.position.y), 0) * DRAG_SPEED

func _process(delta: float) -> void :
	holding = Input.is_action_pressed("hold")

func _physics_process(delta: float) -> void :
	cubey.linear_velocity = (Vector3.ZERO - cubey.position) * MOVE_SPEED * delta
	cubey.angular_velocity = cubey.angular_velocity.lerp(Vector3.ZERO, delta * 20)
	pass
