extends Node3D

const PHYSICS_SCAG = preload("uid://ck3bgxvu814iu")
@onready var scagContainer: Node3D = $"../Scags"
@export var clearButton: Button
@export var spawnButton: Button


func _ready() -> void :
	spawnButton.pressed.connect(spawn)
	clearButton.pressed.connect(clear_all)

func spawn() -> void :
	var scag = PHYSICS_SCAG.instantiate()
	scagContainer.add_child(scag)

func clear_all() -> void :
	for scag in scagContainer.get_children():
		scag.queue_free()

func _process(delta: float) -> void :
	for scag: Node3D in scagContainer.get_children():
		if scag.position.y < -50:
			scag.queue_free()
