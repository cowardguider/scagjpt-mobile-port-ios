extends Control

const AXOSUN_SPLASH = preload("res://addons/godot-axosun-splash/axosun_splash.tscn")

func to_scag():
	get_tree().call_deferred("change_scene_to_file", "res://scenes/main/main.tscn")

func _ready() -> void :
	if Globals.is_game_closing: return

	var args = Util.get_cmdline_args_formatted()
	if args.has("no_intro"):
		to_scag()
		return

	var debug_force_intro = ProjectSettings.get_setting_with_override("application/config/scag/always_play_startup")
	var has_seen_first_time_intro = UserConfig.get_value("intro", "first_time_intro", false)
	var intro_screen_enabled = GameSettings.get_setting("INTRO_SCREEN_ENABLED", true)
	if OS.is_debug_build() and debug_force_intro or !has_seen_first_time_intro or has_seen_first_time_intro and intro_screen_enabled:
		var axosun_splash: AxosunSplash = AXOSUN_SPLASH.instantiate()
		add_child(axosun_splash)
		await axosun_splash.finished
		UserConfig.set_value("intro", "first_time_intro", true)



	to_scag()
