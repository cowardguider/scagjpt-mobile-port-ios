extends DirectionalLight3D

var PIXEL_AMOUNT_X = 5
var PIXEL_AMOUNT_Y = 5
var OFFSET = 0.1



func _ready() -> void :





	pass
