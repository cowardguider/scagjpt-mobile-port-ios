# SCAG iOS build (no Mac needed)
1. Create a GitHub repo (public = free macOS minutes), upload everything in this folder (keep the .github folder).
2. Actions tab -> "Build unsigned iOS IPA" -> Run workflow.
3. When it finishes, download the `scag-unsigned-ipa` artifact, unzip, send scag-unsigned.ipa to your phone.
4. Open it in KSign, sign it with your cert, install.
Notes: set bundle id in export_presets.cfg if you want. Untested - Godot isn't available in my sandbox.
Removed: Steam, godot_gif, gde_gozen (video), Roblox bridge, drag&drop viewer, Win32 worker, tray icon.
