extends Node

var _debug_text



func write(text: String, index: String, lifetime: float = -1):
	if !OS.has_feature("editor_runtime"): return
	if !_debug_text: return
	_debug_text.write(text, index, lifetime)


func _ready() -> void :
	if !OS.has_feature("editor_runtime"): return
	print("Debug enabled!")
	if ProjectSettings.get_setting_with_override("application/config/scag/debug_window_enabled"):
		var DEBUG_TEXT = load("uid://ckfq5wxv4mcih")
		_debug_text = DEBUG_TEXT.instantiate()
		add_child(_debug_text)
