@tool
@icon("uid://bvvu8c56q60gy")
extends Resource
class_name StyleBorder


@export var color: Color = Color(1.0, 1.0, 1.0, 1.0):
	set(v):
		color = v
		emit_changed()


@export var blend: bool:
	set(v):
		blend = v
		emit_changed()


@export var texture: Texture2D:
	set(v):
		texture = v
		emit_changed()



@export var ignore_stack: bool = false:
	set(v):
		ignore_stack = v
		emit_changed()


@export_group("Border width", "width")

@export_range(0, 1, 1, "or_greater", "suffix:px") var width_left: int:
	set(v):
		width_left = v
		emit_changed()


@export_range(0, 1, 1, "or_greater", "suffix:px") var width_top: int:
	set(v):
		width_top = v
		emit_changed()


@export_range(0, 1, 1, "or_greater", "suffix:px") var width_right: int:
	set(v):
		width_right = v
		emit_changed()


@export_range(0, 1, 1, "or_greater", "suffix:px") var width_bottom: int:
	set(v):
		width_bottom = v
		emit_changed()



@export_group("Inset", "inset")



@export var inset_left: int:
	set(v):
		inset_left = v
		emit_changed()



@export var inset_top: int:
	set(v):
		inset_top = v
		emit_changed()



@export var inset_right: int:
	set(v):
		inset_right = v
		emit_changed()



@export var inset_bottom: int:
	set(v):
		inset_bottom = v
		emit_changed()


func get_width(side: Side) -> int:
	match side:
		SIDE_LEFT: return width_left
		SIDE_TOP: return width_top
		SIDE_RIGHT: return width_right
		SIDE_BOTTOM: return width_bottom
	return 0

func get_width_min() -> int:
	return min(width_left, width_top, width_right, width_bottom)

func set_width(side: Side, width: int) -> void :
	match side:
		SIDE_LEFT: width_left = width
		SIDE_TOP: width_top = width
		SIDE_RIGHT: width_right = width
		SIDE_BOTTOM: width_bottom = width

func set_width_all(width: int) -> void :
	width_left = width
	width_top = width
	width_right = width
	width_bottom = width
