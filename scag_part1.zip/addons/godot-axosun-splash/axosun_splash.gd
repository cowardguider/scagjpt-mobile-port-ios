class_name AxosunSplash
extends Control


















signal finished
signal requested_skip

@export_group("Behavior")



@export var automatically_play: bool = true


@export var delete_on_finish: bool = false

@export_group("Skip")


@export var allow_skipping: bool = false


@export var skip_input_action: StringName:
	set(value):
		skip_input_action = value
		set_process( !value.is_empty())



@export_range(0.0, 2.0, 0.1, "suffix:seconds") var skip_hold_duration: float = 1.0


@export var show_skip_tooltip: bool = true



@onready var _animator: AnimationPlayer = $"AnimationPlayer"
var _holding_for: float = 0.0;
var _tipping = false

func _ready() -> void :
	_animator.animation_finished.connect(_animation_finished)
	$"Label".hide()
	if automatically_play:
		play()

func _process(delta: float) -> void :
	if !skip_input_action.is_empty():
		if Input.is_action_pressed(skip_input_action):
			_holding_for += delta
			if _holding_for >= skip_hold_duration:
				_requested_skip()
		else:
			if (_holding_for > 0.0) and !_tipping:
				_skip_tip()
			_holding_for = 0.0




func play() -> void :
	_animator.play(&"intro")


func pause() -> void :
	_animator.pause()


func skip() -> void :
	requested_skip.emit()



func _skip_tip() -> void :
	_tipping = true
	$"Label".show()
	await get_tree().create_timer(1.0).timeout
	$"Label".hide()
	_tipping = false

func _animation_finished(anim_name: StringName) -> void :
	finished.emit()
	if delete_on_finish:
		queue_free()

func _requested_skip() -> void :
	requested_skip.emit()
	_animation_finished("intro")
