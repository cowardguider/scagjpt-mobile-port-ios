shader_type canvas_item;

uniform float body_rotation = 0.0;
global uniform vec3 light_direction;

void fragment() {
	vec4 shape_texture = texture(TEXTURE, UV);
	vec2 centered = UV * 2.0 - 1.0;
	float z = sqrt(max(0.0, 1.0 - dot(centered, centered)));
	vec3 normal = normalize(vec3(centered, z));
	
	float cos_r = cos(body_rotation);
	float sin_r = sin(body_rotation);
	vec3 unrotated_normal = vec3(
	    normal.x * cos_r - normal.y * sin_r,
	    normal.x * sin_r + normal.y * cos_r,
	    normal.z
	);
	
	vec3 light_dir = normalize(light_direction);
	
	float specular_raw = pow(max(dot(unrotated_normal, light_dir), 0.0), 1.2);
	float specular = smoothstep(0.5 - 0.05, 0.5 + 0.05, specular_raw);
	
	COLOR = vec4(specular, specular, specular, shape_texture.a);
}

//void light() {
//	// Called for every pixel for every light affecting the CanvasItem.
//	// Uncomment to replace the default light processing function with this one.
//}
