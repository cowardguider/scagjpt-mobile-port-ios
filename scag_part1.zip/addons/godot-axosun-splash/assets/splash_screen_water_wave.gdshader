shader_type canvas_item;

uniform sampler2D noise_tex1 : repeat_enable;
uniform sampler2D noise_tex2 : repeat_enable;
uniform sampler2D alpha_gradient;
uniform sampler2D color_gradient;

uniform vec2 stretch = vec2(1.0);
uniform float speed = 1.0;
uniform float alpha = 1.0;

void fragment() {
	// manipulate some UVs
	vec2 uv = UV;
	uv -= TIME * speed;
	float a = texture(alpha_gradient, UV).r;
	
	// sample textures
	float a1 = texture(noise_tex1, uv * (stretch / 1.5)).r;
	float a2 = texture(noise_tex2, uv * stretch).r;
	vec3 color = texture(color_gradient, UV).rgb + (step(0.8, a2) / 2.0);
	// combine them
	float combined = a1 * a2;
	
	// do this step thing ?
	float s = step(a, combined);
	COLOR.a = (1.0 - s) * alpha;
	COLOR.rgb = color;
}

//void light() {
//	// Called for every pixel for every light affecting the CanvasItem.
//	// Uncomment to replace the default light processing function with this one.
//}
