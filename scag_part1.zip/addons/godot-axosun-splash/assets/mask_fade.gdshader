shader_type canvas_item;
uniform sampler2D mask;
uniform sampler2D gradient;
uniform float progress : hint_range(0.0, 1.0, 0.001);
uniform float feather : hint_range(0.0, 1.0, 0.001);
uniform float alpha : hint_range(0.0, 1.0, 0.001) = 1.0;


void fragment() {
	float mask_value = 1.0 - texture(mask, UV).r;
	
	float threshold = progress * 1.0 + feather;
	
	COLOR.rgb *= texture(gradient, UV).rgb;
	COLOR.a *= smoothstep(threshold, threshold * 1.0 - feather, mask_value) * alpha;
}