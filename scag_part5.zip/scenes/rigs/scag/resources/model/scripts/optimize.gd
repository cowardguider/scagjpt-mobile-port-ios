extends Material

func _init() -> void :
	print("[optimize.gd]: checking %s | " % resource_name, RenderingServer.get_current_rendering_method())
	if RenderingServer.get_current_rendering_method() != "forward_plus":
		print("[optimize.gd]: Clearing next pass!")
		next_pass = null
