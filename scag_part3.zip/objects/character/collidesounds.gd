extends RigidBody3D

var threshold: float = 1
var min_vol: float = -10
var max_vol: float = -5

var isSliding: bool = false


func _ready() -> void :
	pass


func _on_body_entered(_body: Node) -> void :
	var speed: float = linear_velocity.length()
	if speed > threshold:
		$collide.volume_db = clamp(min_vol + speed, min_vol, max_vol)
		$collide.playing = true


func _on_collide_finished() -> void :
	pass
