class_name _Tutorial extends Node




const TUTORIAL_DIALOGUE_SEQUENCE = preload("uid://bxptk35almgk2")
const QUICK_TUTORIAL = preload("uid://ddmamhm71872")

var _last_known_scale: Vector3 = Vector3.ZERO
var _scale_changes: int = 0
var _time_passed: float = 0

var is_running: bool = false
var current_sequence_index: int = 0
var allow_dialogue_skipping: bool = false
var running_dialogue: DialogueManager.RunningDialogue
var tutorial_sequence: Array[Callable] = [
	func():
		allow_dialogue_skipping = true
		Globals.drag_enabled.add(5, false)
		Globals.poke_enabled.add(5, false)
		Globals.media_player_loading_enabled.add(5, false)
		Globals.menu_mode_toggle_disabled.add(5, true)
		Globals.character.set_state(CharacterWorker.States.IDLE)
		await Util.wait(2)
		running_dialogue = DialogueManager.play_sequence(TUTORIAL_DIALOGUE_SEQUENCE, true, false, {})
		await running_dialogue.on_continue, 
	func():
		allow_dialogue_skipping = false
		_time_passed = 0
		_last_known_scale = Globals.character.scale
		await running_dialogue.on_continue, 

	func():
		allow_dialogue_skipping = false
		Globals.drag_enabled.remove(5)
		Globals.poke_enabled.remove(5)
		await running_dialogue.on_finished_typing
		await running_dialogue.on_continue
		await Util.wait(2), 
	func():
		allow_dialogue_skipping = false, 
	func():
		allow_dialogue_skipping = false
		_time_passed = 0
		await running_dialogue.on_finished_typing
		Globals.media_player_loading_enabled.remove(5)
		await running_dialogue.on_continue, 
	func():

		var media_player = Globals.menu_container.get_node_or_null("DragNDrop")
		if media_player:
			var display = media_player.get_node("DragNDropDisplay")
			if display:
				display._on_toggle_mute_pressed()
		allow_dialogue_skipping = false
		await running_dialogue.on_finished_typing
		Globals.menu_mode_toggle_disabled.remove(5)
		Globals.menu_mode_input_disabled.add(10, true)
		await running_dialogue.on_continue, 
	func():
		allow_dialogue_skipping = true
		Globals.menu_mode_toggle_disabled.add(5, true)
		await running_dialogue.on_continue, 
	func():
		allow_dialogue_skipping = true
		Globals.media_player_loading_enabled.add(5, false)

		var media_player = Globals.menu_container.get_node_or_null("DragNDrop")
		if media_player:
			var display = media_player.get_node("DragNDropDisplay")
			if display:
				display._on_close_button_pressed()
		await running_dialogue.on_continue
		await running_dialogue.on_continue
		await running_dialogue.on_continue
		Globals.menu_mode_input_disabled.remove(10), 
	func():
		Globals.character.set_state(CharacterWorker.States.IDLE)
		Globals.poke_enabled.add(5, false)
		await running_dialogue.on_continue
		Globals.menu_mode_toggle_disabled.remove(5)
		Globals.poke_enabled.remove(5)
		Globals.media_player_loading_enabled.remove(5)
]

func has_done_tutorial() -> bool:
	return UserConfig.get_value("game", "completed_tutorial", false)

func run_tutorial() -> void :
	is_running = true
	print("[tutorial.gd]: Running tutorial.")

	if GameSettings.get_setting("SCAG_ROAMING", false):
		GameSettings.set_setting_and_update("SCAG_ROAMING", false)

	for callback in tutorial_sequence:
		current_sequence_index = tutorial_sequence.find(callback)
		print("[tutorial.gd]: Sequence %s." % current_sequence_index)
		await callback.call()
	is_running = false
	print("[tutorial.gd]: End of tutorial.")
	UserConfig.set_value("game", "completed_tutorial", true)
	UserConfig.save_to_file()

func _on_state_changed(new_state: CharacterWorker.States, old_state: CharacterWorker.States) -> void :
	if old_state == CharacterWorker.States.ENTER:
		if OS.has_feature("editor") and ProjectSettings.get_setting_with_override("application/config/scag/always_play_tutorial") or !has_done_tutorial():
			run_tutorial()
		elif GameSettings.get_setting("QUICK_TUTORIAL", true):
			var window = QUICK_TUTORIAL.instantiate()
			get_tree().current_scene.add_child(window)


	if is_running and running_dialogue:
		if current_sequence_index == 2 and new_state == CharacterWorker.States.DRAGGING and !running_dialogue.is_typing:
			running_dialogue.proceed()
		elif current_sequence_index == 5 and new_state == CharacterWorker.States.MENU_MODE:
			running_dialogue.proceed()

func _ready() -> void :
	Globals.tutorial = self
	Globals.character.state_changed.connect(_on_state_changed)

func _process(delta: float) -> void :
	if is_running and allow_dialogue_skipping and running_dialogue and Input.is_action_just_released("hold"):
		running_dialogue.proceed()

	if is_running and running_dialogue:
		if current_sequence_index == 4 and Globals.menu_container.get_node_or_null("DragNDrop"):
			running_dialogue.proceed()
		elif current_sequence_index == 1 and !running_dialogue.is_typing:


			if _last_known_scale != Globals.character.scale:
				_scale_changes += 1
				_last_known_scale = Globals.character.scale
				if _scale_changes > 20:
					running_dialogue.proceed()

			if _scale_changes != 0:
				_time_passed += delta
			if _time_passed > 10:
				running_dialogue.proceed()
