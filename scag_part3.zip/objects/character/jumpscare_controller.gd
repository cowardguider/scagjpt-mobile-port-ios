extends Node
@onready var character: CharacterWorker = $".."
enum RingType{POMO, ALARM}

const BREAK_TIME_LINES: DialogueCollection = preload("uid://s6iel71teldg")
const LONG_BREAK_TIME_LINES: DialogueCollection = preload("uid://bggm7qadrmsqd")
const ALARM_LINES: DialogueCollection = preload("uid://crysxjg4svjv8")
const WORK_TIME_LINES: DialogueCollection = preload("uid://bliqpo4csq1sv")

const RING_DISPLAY = preload("uid://c2d18kxaqmxjm")
const MAX_FREQUENCY: float = 11050.0
const UPDATE_FREQ: float = 0.03

var active_ring_display: AppBase
var active_dialogue: DialogueManager.RunningDialogue
var origin: Variant
var _bus_index: int = 0
var _bus_effect: AudioEffectSpectrumAnalyzerInstance
var _last_update: float = 0

func jumpscare(data: Variant, ring_type: RingType) -> void :
	if active_ring_display: return
	var last_state: CharacterWorker.States = character.state

	if last_state != CharacterWorker.States.MENU_MODE:
		character.set_state(CharacterWorker.States.MENU_MODE)

	character.rig.set_wiggle_enabled(true, ["DontGrabMe"])

	var sequence: DialogueSequence
	if ring_type == RingType.POMO:
		if data == ClockManager.PomoType.POMO:
			sequence = BREAK_TIME_LINES.pick_random_line()
		else:
			sequence = WORK_TIME_LINES.pick_random_line()
	else:
		sequence = ALARM_LINES.pick_random_line()
	active_ring_display = RING_DISPLAY.instantiate()
	Globals.menu_container.add_child(active_ring_display)
	active_ring_display.get_node("Worker").play()
	origin = Globals.camera.offset_priority.get_prioritized_value()
	for dialog in sequence.sequence:
		dialog.input_type = Dialogue.InputType.SCRIPTED
		dialog.dialogue_box_type = DialogueManager.BoxType.MENU_MODE
	active_dialogue = DialogueManager.play_sequence(sequence, true, true, {})
	set_process(true)
	await active_dialogue.on_complete
	set_process(false)
	active_dialogue = null
	active_ring_display.get_node("Worker").close()
	active_ring_display = null
	origin = null
	_last_update = 0
	Globals.camera.offset_priority.remove(8)
	character.rig.set_wiggle_enabled(false)


	if last_state in [CharacterWorker.States.DRAGGING, CharacterWorker.States.PLACED, CharacterWorker.States.RAGDOLLED, CharacterWorker.States.POKED]:
		last_state = CharacterWorker.States.IDLE




	if character.state == CharacterWorker.States.MENU_MODE and last_state != CharacterWorker.States.MENU_MODE:
		character.set_state(last_state)



func _process(delta: float) -> void :
	if active_dialogue and Input.is_action_just_released("hold"):
		active_dialogue.proceed()

	if origin:
		_last_update += delta
		if _last_update < UPDATE_FREQ: return
		_last_update = 0
		var amount = _bus_effect.get_magnitude_for_frequency_range(MAX_FREQUENCY * 0.01, MAX_FREQUENCY, AudioEffectSpectrumAnalyzerInstance.MAGNITUDE_AVERAGE).length()



		var random_offset = Vector3(randf_range( - amount, amount), randf_range( - amount, amount), 0)
		var random_position = origin + random_offset
		character.rig.apply_wiggle_force(random_offset)
		Globals.camera.offset_priority.add(8, random_position)

func _ready() -> void :
	set_process(false)
	ClockManager.on_pomo_ring.connect(jumpscare.bind(RingType.POMO))
	ClockManager.on_alarm_ring.connect(jumpscare.bind(RingType.ALARM))
	_bus_index = AudioServer.get_bus_index("Ringtone")
	_bus_effect = AudioServer.get_bus_effect_instance(_bus_index, 0)
