class_name CharacterCamera extends Camera3D

@export var distance_from_target = 6.0
@onready var character: CharacterWorker = $"../Character"
var offset_priority: PriorityManager = PriorityManager.new(Vector3.ZERO)

func reset():
	var _aabb = Globals.character.rig.get_bounding_box()

	var bounding_box = Globals.character.rig.global_transform * _aabb
	position = bounding_box.get_center() + Vector3(0, 0, distance_from_target) + offset_priority.get_prioritized_value()


func _ready() -> void :
	Globals.camera = self
	process_priority = 5



func _process(delta: float) -> void :

	var window_size = DisplayServer.window_get_size(0)
	var window_sides = window_size / 2
	var diff: Vector2i = ScreenBounds.target_window_position - DisplayServer.window_get_position()
	var clamped_diff: Vector2i = Vector2i(clampi(diff.x, - window_sides.x, window_sides.x), clampi(diff.y, - window_sides.y, window_sides.y))








	if Globals.character.state == CharacterWorker.States.RAGDOLLED:
		var ragdoller: RigidBody3D = Globals.character.get_node("Ragdoller")
		var camera_pos = position
		var target_pos = Globals.camera.project_position(window_sides - clamped_diff, 2)
		camera_pos.z = 0
		target_pos.z = 0
		var camera_offset = target_pos - camera_pos
		position = position.slerp(ragdoller.global_transform.translated_local(Vector3.UP).origin + Vector3(0, 0, distance_from_target) + camera_offset, clampf(delta * 50, 0, 1))



	elif Globals.character.state != CharacterWorker.States.MENU_MODE:
		reset()
		var target_pos = Globals.camera.project_position(window_sides - clamped_diff, 2)
		position = target_pos
	else:
		reset()
