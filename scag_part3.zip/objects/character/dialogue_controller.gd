class_name DialogueController extends Node

var collections = {
	"exit": preload("uid://ikdf2axy8h48"), 
	"exit_warn": preload("uid://b7twq06hgtbwj"), 
	"hit": preload("uid://yhqthi1i8g7y"), 
	"startup": preload("uid://m22f61sttdue"), 
	"file_general": preload("uid://cov6bgw4hkdn2"), 
	"file_video": preload("uid://ttx4gmwyd8mq"), 
	"file_image": preload("uid://dcbvf7a2why81"), 
	"file_gif": preload("uid://32h84s1nn026"), 
	"ragebait": preload("uid://m8tsbp7t6flh")
}

var cooldowns: Dictionary[String, float] = {}

func play_random_line_from_collection(collection: DialogueCollection, index: String = "", cooldown: float = 0, no_anim: bool = false, string_format: Variant = {}) -> void :

	if index != "":
		if cooldowns.has(index):
			return
		if cooldown > 0:
			cooldowns[index] = cooldown

	DialogueManager.play_sequence(collection.pick_random_line(), false, no_anim, string_format)

func _process(delta: float) -> void :
	for index in cooldowns:
		var cooldown: float = cooldowns[index]

		cooldown -= delta
		if cooldown < 0:
			cooldowns.erase(index)
			continue
		cooldowns[index] = cooldown
