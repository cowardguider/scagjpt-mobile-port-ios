class_name CharacterWorker extends Node3D





enum States{IDLE, DRAGGING, MENU_MODE, POKED, ROAMING, PLACED, RAGDOLLED, ENTER, LEAVE, TEST_ZOOM, TWERK}

const TIME_LIMIT_TO_POKE: float = 0.15
const DEFAULT_OFFSET = 2

signal state_changed(new_state: States, previous_state: States)

@onready var rig: Rig = $Rig
@onready var dialogue_controller: DialogueController = $DialogueController
@onready var roaming_controller: RoamingController = $RoamingController
var state: States
var roaming_enabled: bool = false

var _last_scale: Vector3 = Vector3.ZERO
var _last_click: float = 0
var _can_click: float = 0
var _last_mouse_pos: Vector2 = Vector2.ZERO
var _mouse_velocity: Vector2 = Vector2.ZERO
var _last_window_position: Vector2i = Vector2i.ZERO
var _drag_offset: Vector2
var _drag_lerp: Vector2



func set_state(new_state: States) -> void :
	var previous_state = state
	state = new_state
	print("Going from " + str(States.find_key(previous_state)) + " to " + str(States.find_key(state)))


	match previous_state:
		States.IDLE:

			_last_click = 0
			pass
		States.POKED:

			ScreenBounds.clear_mouse_space_scale(5)
			ScreenBounds.clear_mouse_space_offset(5)
			pass
		States.MENU_MODE:

			add_poke_block_time(0.2)
			rig.clear_menu_visible_priority(10)
			Globals.menu_mode_input_disabled.add(5, true)
			visible = false
			ScreenBounds.clear_window_size(5)
			await Util.wait_screen_refresh()
			ScreenBounds.set_position(_last_window_position)
			Globals.camera.offset_priority.remove(5)

			scale = _last_scale
			visible = true


			await Util.wait_screen_refresh()
			ScreenBounds.clear_mouse_space_offset(7)
			pass
		States.ROAMING:


			pass
		States.DRAGGING:

			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
			Globals.menu_mode_input_disabled.remove(8)
			ScreenBounds.clear_mouse_space_scale(6)
			ScreenBounds.clear_mouse_space_offset(6)
			rig.set_wiggle_enabled(false)
			$SFX / wind.playing = false

			pass
		States.PLACED:
			ScreenBounds.clear_mouse_space_scale(5)
			pass
		States.RAGDOLLED:
			_last_click = 0
			$Ragdoller.visible = false
			rig.reparent(self, false)
			rig.visible = true
			$Ragdoller.freeze = true
			$Ragdoller.transform = Transform3D.IDENTITY
			ScreenBounds.clear_mouse_space_scale(6)
			rig.set_wiggle_enabled(false)
		States.ENTER:
			ScreenBounds.clear_window_size(1)
			ScreenBounds.set_position_with_ratio(Vector2(0.5, 0.5), Vector2(0.5, 0.5))
			scale = Globals.CHARACTER_SCALE_MAX * Vector3.ONE
			rig.set_animation_state(Rig.AnimationStates.DEFAULT)
			await Util.wait_screen_refresh()
			ScreenBounds.clear_mouse_space_scale(8)



	state_changed.emit(state, previous_state)


	match state:
		States.IDLE:
			_can_click = 0.2
			rig.set_animation_state(Rig.AnimationStates.DEFAULT)
			if roaming_enabled:
				call_deferred("set_state", States.ROAMING)
			pass
		States.POKED:

			ScreenBounds.set_mouse_space_scale(5, 0.2)
			ScreenBounds.set_mouse_space_offset(5, Vector2(0, -50))

			rig.poke()
			$SFX / poked.play()
			$SFX / scag_poked.play()
			emit_particle_at_screen_pos($Punch, Util.get_mouse_position(), 1)

			if not fall_for_the_ragebait():
				dialogue_controller.play_random_line_from_collection(dialogue_controller.collections.hit, "hit", 60)

			call_deferred("_process_after_anim")

			pass
		States.MENU_MODE:

			rig.set_menu_visible_priority(10, true)
			Globals.menu_mode_input_disabled.remove(5)




			rig.set_animation_state(Rig.AnimationStates.MENU_MODE)
			_last_scale = scale
			scale = 0.9 * Vector3.ONE
			var target_screen = Util.get_current_screen()
			var screen_rect = DisplayServer.screen_get_usable_rect(target_screen)
			if screen_rect.size.y > screen_rect.size.x:
				ScreenBounds.set_window_size(5, Vector2i(screen_rect.size.x, screen_rect.size.x))
			else:
				ScreenBounds.set_window_size(5, Vector2i(screen_rect.size.y, screen_rect.size.y))
			_last_window_position = ScreenBounds.target_window_position
			ScreenBounds.set_position_with_ratio(Vector2(0.5, 1), Vector2(0.5, 1), target_screen)
			Globals.camera.offset_priority.add(5, Vector3(0, 0.38, 0))
			await Util.wait_screen_refresh()
			ScreenBounds.set_mouse_space_offset(7, Vector2(0, -90))

			pass
		States.ROAMING:

			pass
		States.DRAGGING:

			_last_mouse_pos = DisplayServer.mouse_get_position()
			rig.set_wiggle_enabled(true)
			Globals.menu_mode_input_disabled.add(5, true)
			var camera = get_viewport().get_camera_3d()
			if camera is CharacterCamera:
				get_viewport().get_camera_3d().reset()
			_drag_lerp = - Util.get_mouse_position()
			_drag_offset = - get_viewport().get_camera_3d().unproject_position(rig.grab_position.global_position)



			$SFX / wind.playing = true
			rig.set_animation_state(Rig.AnimationStates.DRAGGING)
			$SFX / grab.playing = true
			ScreenBounds.set_mouse_space_scale(6, 2)
			ScreenBounds.set_mouse_space_offset(6, Vector2(-50, 0))

		States.PLACED:
			ScreenBounds.set_mouse_space_scale(5, 0.25)
			rig.set_animation_state(Rig.AnimationStates.PLACED)
			$SFX / land.playing = true


			fall_for_the_ragebait()

			call_deferred("_process_after_anim")
			pass
		States.RAGDOLLED:
			var window_size: Vector2i = DisplayServer.window_get_size(0)
			var window_position: Vector2i = DisplayServer.window_get_position(0)
			position = Globals.screen_collision.get_position_for_character(window_position + window_size / 2)
			$SFX / thrown.playing = true
			$SFX / swish.playing = true
			rig.set_animation_state(Rig.AnimationStates.RAGDOLLED)
			rig.reparent($Ragdoller, false)
			$Ragdoller.visible = true
			$Ragdoller.freeze = false
			ScreenBounds.set_mouse_space_scale(6, 0.25)
			var impulse_vel = _mouse_velocity / 2.5
			$Ragdoller.apply_impulse(Vector3(impulse_vel.x, - impulse_vel.y, 0))
			rig.position = Vector3.ZERO
			rig.set_wiggle_enabled(true, ["DontGrabMe"])
			_mouse_velocity = Vector2.ZERO


			fall_for_the_ragebait()

		States.ENTER:


			ScreenBounds.set_mouse_space_scale(8, 5)
			ScreenBounds.set_window_size(1, Globals.DEFAULT_WINDOW_SIZE + Vector2i(0, 280))
			ScreenBounds.set_position_with_ratio(Vector2(0.5, 0.5), Vector2(0.5, 0.5))
			scale = (Globals.CHARACTER_SCALE_MAX - 0.035 * 2) * Vector3.ONE
			ScreenBounds.refresh()
			rig.set_animation_state(Rig.AnimationStates.ENTER)
			set_deferred("visible", true)
			call_deferred("_process_after_anim")
			await Util.wait(0.7)
			dialogue_controller.play_random_line_from_collection(dialogue_controller.collections.startup, "", 0, true)
		States.LEAVE:
			dialogue_controller.play_random_line_from_collection(dialogue_controller.collections.exit)
			rig.set_animation_state(Rig.AnimationStates.LEAVE)
			await Util.wait(2.5)
			visible = false
			get_tree().quit()

		States.TEST_ZOOM:
			GameSettings.set_setting("SCAG_ROAMING", false)
			Globals.drag_enabled.add(10, false)
			Globals.poke_enabled.add(10, false)
			Globals.menu_mode_toggle_disabled.add(10, false)
			Globals.media_player_loading_enabled.add(10, false)
			rig.set_animation_state(Rig.AnimationStates.DEFAULT)
			rig.set_is_talking(true)

			var usable_rect = DisplayServer.screen_get_usable_rect(Util.get_current_screen())
			ScreenBounds.mouse_passthrough_enabled.add(10, false)
			ScreenBounds.set_window_size(10, usable_rect.size - Vector2i(0, 1))
			ScreenBounds.set_position(usable_rect.position)
			var lala = float(usable_rect.size.x) / float(usable_rect.size.y)


			Globals.camera.offset_priority.add(10, Vector3(0, 0.1, 0))
			await Util.wait(0.5)
			Globals.face_menu.get_node("Zoom").visible = true
			rig.set_menu_visible_priority(10, true)
			var tweeny = create_tween()
			tweeny.set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_QUART)
			tweeny.tween_property(self, "scale", Vector3.ONE * 4, 2)
			tweeny.parallel()
			var bruh = func(numb): Globals.camera.offset_priority.add(10, numb)
			tweeny.tween_method(bruh, Vector3(0, 0.1, 0), Vector3(0, 1.8, 0), 2)
			tweeny.play()
		States.TWERK:

			set_state(States.LEAVE)



func emit_particle_at_screen_pos(particle: GPUParticles3D, screen_position: Vector2, z_depth: float):
	var world_position = get_viewport().get_camera_3d().project_position(screen_position, z_depth)
	particle.emit_particle(Transform3D(Basis.IDENTITY, world_position), Vector3.ZERO, Color.WHITE, Color.WHITE, GPUParticles3D.EmitFlags.EMIT_FLAG_POSITION | GPUParticles3D.EmitFlags.EMIT_FLAG_ROTATION_SCALE)


func add_poke_block_time(amt: float) -> void :
	_can_click += amt


func play_sound(sound_name: String, duplicate_sound: bool = false) -> void :
	var sfx: AudioStreamPlayer = $SFX.get_node_or_null(sound_name)
	if sfx:
		if duplicate_sound:
			var clone: AudioStreamPlayer = sfx.duplicate()
			$SFX.add_child(clone)
			clone.play()
			await clone.finished
			clone.queue_free()
		else:
			sfx.play()
	else:
		push_warning("[character_worker.gd]: No sound named %s found." % sound_name)









func fall_for_the_ragebait() -> bool:
	var last_loss: float = Globals.ragebait
	var current_time: float = Time.get_ticks_msec() / 1000.0
	var time_difference: float = current_time - last_loss

	if last_loss != -999.0 and time_difference <= 10.0:
		print("ragebait activated")
		Globals.ragebait = -999.0

		if is_instance_valid(dialogue_controller) and dialogue_controller.collections.has("ragebait"):
			dialogue_controller.play_random_line_from_collection(dialogue_controller.collections.ragebait)
			return true

	return false




func _process_after_anim():
	await rig.animation_tree.animation_finished
	if state in [States.POKED, States.PLACED]:
		set_state(States.IDLE)




	if state == States.ENTER:
		set_state(States.IDLE)




func _input(event: InputEvent) -> void :
	var _is_menu_visible = rig._menu_visibility_priority.get_prioritized_value()
	var _is_input_disabled = Globals.menu_mode_input_disabled.get_prioritized_value()

	if _is_menu_visible and !_is_input_disabled and !Globals.gui_3d.is_mouse_inside or !_is_menu_visible or _is_menu_visible and _is_input_disabled:
		if state in [States.IDLE, States.ROAMING]:
			var new_scale = scale.y
			if event.is_action_pressed("zoom_in"):
				new_scale += 0.01
			elif event.is_action_pressed("zoom_out"):
				new_scale += -0.01
			elif event is InputEventMagnifyGesture:
				new_scale += (event.factor - 1) / 2
			new_scale = clampf(new_scale, Globals.CHARACTER_SCALE_MIN, Globals.CHARACTER_SCALE_MAX)
			var new_vector_scale = Vector3.ONE * new_scale
			if new_vector_scale != scale:
				scale = Vector3.ONE * new_scale
				ScreenBounds.refresh()



	if state == States.DRAGGING:
		if event is InputEventMouseMotion:

			var new_mouse_pos: Vector2 = DisplayServer.mouse_get_position()
			var vel = new_mouse_pos - _last_mouse_pos
			_last_mouse_pos = new_mouse_pos
			if vel.length() > _mouse_velocity.length():
				_mouse_velocity = vel



			var force = vel * 0.0003
			rig.apply_wiggle_force(Vector3( - force.x, force.y, 0))






func _process(delta: float) -> void :
	var _is_menu_visible = rig._menu_visibility_priority.get_prioritized_value()
	var _is_input_disabled = Globals.menu_mode_input_disabled.get_prioritized_value()
	Debugger.write("_is_menu_visible: %s" % _is_menu_visible, "_is_menu_visible")
	Debugger.write("_is_input_disabled: %s" % _is_input_disabled, "_is_input_disabled")
	if _is_menu_visible and !_is_input_disabled and not state in [States.MENU_MODE, States.IDLE, States.ROAMING]:
		if Globals.gui_3d.is_mouse_inside:
			return
	if state in [States.IDLE, States.ROAMING]:
		if _is_menu_visible and !Globals.gui_3d.is_mouse_inside or !_is_menu_visible or _is_input_disabled:
			if !Globals.gui_3d.pressed_block:

				_can_click = max(_can_click - delta, 0)



				if Input.is_action_pressed("hold"):
					_last_click += delta
					if _last_click > TIME_LIMIT_TO_POKE and Globals.drag_enabled.get_prioritized_value():
						set_state(States.DRAGGING)
						_last_click = 0

				if Input.is_action_just_released("hold"):
					if _last_click < TIME_LIMIT_TO_POKE and Globals.poke_enabled.get_prioritized_value() and _can_click == 0:
						set_state(States.POKED)
					_last_click = 0

			if Input.is_action_just_pressed("right_click"):
				if !Globals.menu_mode_toggle_disabled.get_prioritized_value():
					set_state(States.MENU_MODE)
				else:
					play_sound("error", true)
	elif state == States.DRAGGING:

		var min_drag_pitch: float = 0.7
		var max_drag_pitch: float = 1.5
		var min_drag_vol: float = -80
		var max_drag_vol: float = 1
		var smoothing_speed: float = 5.0
		var difference: float = max_drag_pitch - min_drag_pitch

		var xymousevelocity: float = _mouse_velocity.length()
		var velocity_calc: float = min_drag_pitch + smoothstep(min_drag_pitch, max_drag_pitch, abs(xymousevelocity) / 50) * difference

		$SFX / wind.pitch_scale = lerp($SFX / wind.pitch_scale, velocity_calc, delta * smoothing_speed)
		$SFX / wind.volume_db = lerp($SFX / wind.volume_db, lerp(min_drag_vol, max_drag_vol, smoothstep(0.0, 5.0, xymousevelocity)), delta * 5.0)

		_drag_lerp = lerp(_drag_lerp, _drag_offset, clampf(delta * 12.0, 0, 1))
		var mouse_pos = DisplayServer.mouse_get_position()
		var new_screen = DisplayServer.get_screen_from_rect(Rect2(mouse_pos, Vector2i.ONE))
		if Util.get_current_screen() != new_screen:
			ScreenBounds.queued_new_screen = new_screen

		ScreenBounds.set_position_raw(mouse_pos + Vector2i(_drag_lerp))










		_mouse_velocity = _mouse_velocity.lerp(Vector2.ZERO, delta * 40)
		if Input.is_action_just_released("hold"):
			if _mouse_velocity.length() > 4:
				set_state(States.RAGDOLLED)
			else:
				set_state(States.PLACED)


	elif state == States.MENU_MODE:
		if Input.is_action_just_pressed("right_click"):
			if !Globals.menu_mode_toggle_disabled.get_prioritized_value():
				set_state(States.IDLE)
			else:
				play_sound("error", true)

	elif state == States.POKED:

		if Input.is_action_just_pressed("hold"):
			rig.animator.stop()
			rig.poke()
			$SFX / poked.play()
			$SFX / scag_poked.play()
			emit_particle_at_screen_pos($Punch, Util.get_mouse_position(), 1)
	elif state == States.RAGDOLLED:
		ScreenBounds.refresh()

		var body_transform: Transform3D = $Ragdoller.global_transform
		var screen_coll_position = Globals.screen_collision.get_position_for_window(body_transform.translated_local(Vector3.UP).origin)
		ScreenBounds.set_position(screen_coll_position, Vector2(0.5, 0.5), null)

		if Input.is_action_pressed("hold"):
			set_state(States.DRAGGING)


func _enter_tree() -> void :
	visible = false

func _ready() -> void :
	roaming_enabled = GameSettings.get_setting("SCAG_ROAMING", false)
	Globals.character = self
	DialogueManager.voice_box = %VoiceBox

	Globals.menu_mode_input_disabled.add(5, true)
	if Util.get_cmdline_args_formatted().has("no_intro"):
		visible = true
		set_state(States.IDLE)
	else:
		set_state(States.ENTER)
