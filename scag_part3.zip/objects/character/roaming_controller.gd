class_name RoamingController extends Node


@export var TIME_MIN: float = 2.4
@export var TIME_MAX: float = 7.8

var roam_timer = Timer.new()
var character: CharacterWorker

var _tween: Tween

func get_random_roam_position(target_screen: int = Util.get_current_screen()) -> Vector2i:
	var screen_rect = DisplayServer.screen_get_usable_rect(target_screen)
	var window_size = DisplayServer.window_get_size(0)
	var inset = Vector2i(window_size.x * character.scale.x, window_size.y * character.scale.y)
	Debugger.write("Inset: {0}".format([inset]), "isnett")
	return Vector2i(
		randi_range(screen_rect.position.x, screen_rect.position.x + screen_rect.size.x - window_size.x / 2), 
		randi_range(screen_rect.position.y, screen_rect.position.y + screen_rect.size.y - window_size.y / 2)
	)

func roam_to(new_position: Vector2i, walk_speed: float) -> void :
	var position = ScreenBounds.target_window_position

	var speed = position.distance_to(new_position) / walk_speed
	if speed > 0.01:
		if new_position.x > position.x:
			character.rotation.y = deg_to_rad(-180 + 30)
			ScreenBounds.set_mouse_space_scale(3, 0.1)
			ScreenBounds.set_mouse_space_offset(3, Vector2(50, 0))
		else:
			character.rotation.y = deg_to_rad(-180 - 30)
			ScreenBounds.set_mouse_space_offset(3, Vector2(-20, 0))

		if _tween: _tween.kill()
		_tween = create_tween()
		_tween.set_ease(Tween.EASE_IN_OUT).set_trans(Tween.TRANS_LINEAR)

		_tween.tween_method(_tween_progress, position, new_position, speed)
		_tween.play()
		character.rig.set_is_walking(true)

		await _tween.finished
		cancel_roam_to()

func cancel_roam_to() -> void :
	if _tween: _tween.kill()
	character.rotation.y = deg_to_rad(-180)
	ScreenBounds.clear_mouse_space_offset(3)
	ScreenBounds.clear_mouse_space_scale(3)
	character.rig.set_is_walking(false)

func _tween_progress(progress: Vector2i):
	Debugger.write("Move to progress: {0}".format([progress]), "movetoprogress")
	ScreenBounds.set_position(progress)
	ScreenBounds.refresh()

func _on_roam_timer_timeout():
	if character.state != CharacterWorker.States.ROAMING: return
	await roam_to(get_random_roam_position(), 300)
	roam_timer.start(randf_range(TIME_MIN, TIME_MAX))



func _on_state_changed(new_state: CharacterWorker.States, old_state: CharacterWorker.States):
	if new_state == CharacterWorker.States.ROAMING:
		roam_timer.start(randf_range(TIME_MIN, TIME_MAX))
	elif old_state == CharacterWorker.States.ROAMING:
		roam_timer.stop()
		cancel_roam_to()

func _ready() -> void :
	character = get_parent()
	character.state_changed.connect(_on_state_changed)
	add_child(roam_timer)
	roam_timer.timeout.connect(_on_roam_timer_timeout)
