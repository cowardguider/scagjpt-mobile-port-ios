class_name ScreenCollision extends Node3D

const FORWARD_DISTANCE = 2
const SCALE_OFFSET = 0

@onready var bottom: MeshInstance3D = $bounding / Bottom
@onready var top: MeshInstance3D = $bounding / Top
@onready var left: MeshInstance3D = $bounding / Left
@onready var right: MeshInstance3D = $bounding / Right

var current_size: Vector2i

func get_position_for_character(new_position: Vector2i) -> Vector3:
	var screen_rect = DisplayServer.screen_get_usable_rect(Util.get_current_screen())
	Debugger.write("mauspos: {0}".format([new_position]), "mauspos", 20)
	return Vector3(
		remap(float(new_position.x), screen_rect.position.x, screen_rect.position.x + screen_rect.size.x, left.global_position.x, right.global_position.x), 
		remap(float(new_position.y), screen_rect.position.y, screen_rect.position.y + screen_rect.size.y, top.global_position.y, bottom.global_position.y), 
		0
	)

func get_position_for_window(new_position: Vector3) -> Vector2i:



	var screen_rect = DisplayServer.screen_get_usable_rect(Util.get_current_screen())


	Debugger.write("position offset: {0}".format([
		Vector2(
			remap(new_position.x, left.global_position.x, right.global_position.x, 0, 1), 
			remap(new_position.y, top.global_position.y, bottom.global_position.y, 0, 1)
		)
	]), "posioffset")
	return Util.clamp_to_target_screen_size(Util.get_current_screen(), Vector2i(
		remap(new_position.x, left.global_position.x, right.global_position.x, screen_rect.position.x, screen_rect.position.x + screen_rect.size.x), 
		remap(new_position.y, top.global_position.y, bottom.global_position.y, screen_rect.position.y, screen_rect.position.y + screen_rect.size.y)
	))

func _on_resolution_changed() -> void :
	var camera = get_viewport().get_camera_3d()

	var screen_size = Vector2(DisplayServer.screen_get_size(Util.get_current_screen()))
	var height = tan(deg_to_rad(camera.fov / 2) * 2 * FORWARD_DISTANCE)
	var width = (screen_size.x / screen_size.y) * height
	scale.x = width + SCALE_OFFSET
	scale.y = height + SCALE_OFFSET

func _process(_delta: float) -> void :
	var new_size = DisplayServer.screen_get_size(Util.get_current_screen())
	if current_size != new_size:
		current_size = new_size
		_on_resolution_changed()


func _ready() -> void :
	Globals.screen_collision = self
