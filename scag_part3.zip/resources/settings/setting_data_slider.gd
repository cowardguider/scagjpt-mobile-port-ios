class_name SettingDataSlider
extends SettingData

@export var value: float:
	set(new):
		var clamped = clampf(new, slider_min, slider_max)
		value = clamped
		slider_value = clamped

func _init(p_callback: Callable, p_category: int = 0, p_name: String = "", p_default: float = 0.5, p_min: float = 0.0, p_max: float = 1.0, p_step: float = 0.1) -> void :
	callable = p_callback
	category = p_category
	id = p_name
	slider_default = p_default
	slider_min = p_min
	slider_max = p_max
	slider_step = p_step
