class_name SettingDataBoolean
extends SettingData

@export var value: bool:
	set(new):
		value = new
		boolean_value = new

func _init(p_callback: Callable, p_category: int = 0, p_name: String = "", p_default: bool = false) -> void :
	callable = p_callback
	category = p_category
	id = p_name
	boolean_default = p_default
