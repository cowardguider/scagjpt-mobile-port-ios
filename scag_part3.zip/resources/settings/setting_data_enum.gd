class_name SettingDataEnum
extends SettingData

@export var value: int:
	set(new):
		value = new
		enum_value = new

func _init(p_callback: Callable, p_category: int = 0, p_arguments: Array[String] = [], p_default: int = 0, p_name: String = "") -> void :
	callable = p_callback
	category = p_category
	id = p_name
	enum_arguments = p_arguments
	enum_default = p_default
