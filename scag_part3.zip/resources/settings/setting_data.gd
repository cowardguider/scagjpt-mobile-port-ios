class_name SettingData
extends Resource

@export var id: StringName
@export var category: int
var callable: Callable

@export_category("Bool")
@export var boolean_default: bool
@export var boolean_value: bool

@export_category("Enum")
@export var enum_arguments: Array[String]
@export var enum_default: int
@export var enum_value: int

@export_category("Slider")
@export var slider_default: float
@export var slider_value: float
@export var slider_min: float
@export var slider_max: float
@export var slider_step: float
