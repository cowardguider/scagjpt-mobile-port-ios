extends Node
const EXIT_WARN_LINES: DialogueCollection = preload("uid://b7twq06hgtbwj")


var no_more_clicks = false

func _on_yes_button_pressed() -> void :
	if no_more_clicks: return
	no_more_clicks = true
	Globals.character.set_state(CharacterWorker.States.LEAVE)

func _on_no_button_pressed() -> void :
	if no_more_clicks: return
	no_more_clicks = true
	get_parent().close()

func _on_close_button_pressed() -> void :
	if no_more_clicks: return
	no_more_clicks = true

	get_parent().close()

func _ready() -> void :
	%ConfirmationLabel.text = EXIT_WARN_LINES.single_lines.pick_random().text
