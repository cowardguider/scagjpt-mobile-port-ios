extends Node

@onready var app_base: AppBase = $".."
@export var top_buttons: ButtonGroup
@onready var title_bar: Control = %TitleBar
var current_button: String = ""

func switch_to(menu: Control, button: BaseButton):
	%StopwatchContainer.visible = false
	%TimerContainer.visible = false
	%PomodoroContainer.visible = false
	button.button_pressed = true
	menu.visible = true
	current_button = button.name
	match button.name:
		"TimerButton":
			title_bar.title = "Clock - Alarms"
			Globals.character.rig.set_menu_visible_priority(2, false)
		"StopwatchButton":
			title_bar.title = "Clock - Stopwatch"
			Globals.character.rig.set_menu_visible_priority(2, true)
		"PomodoroButton":
			title_bar.title = "Clock - Pomodoro"
			Globals.character.rig.set_menu_visible_priority(2, true)

	ClockManager.last_tab = menu.get_path()
	ClockManager.last_button = button.get_path()

func _on_top_button_pressed(button: BaseButton) -> void :
	match button.name:
		"TimerButton":
			switch_to( %TimerContainer, button)
		"StopwatchButton":
			switch_to( %StopwatchContainer, button)
		"PomodoroButton":
			switch_to( %PomodoroContainer, button)

func _on_close_button_pressed() -> void :
	Globals.character.rig.clear_menu_visible_priority(2)
	Globals.menu_mode_input_disabled.remove(8)
	app_base.close()

func _process(_delta: float) -> void :
	if Globals.character.state == CharacterWorker.States.MENU_MODE:
		%TopButtons.modulate = Color(1.0, 1.0, 1.0, 1.0)
		Globals.menu_mode_input_disabled.remove(8)
	else:
		%TopButtons.modulate = Color(1.0, 1.0, 1.0, 0.0)
		if current_button == "StopwatchButton":
			Globals.menu_mode_input_disabled.add(8, false)

func _ready() -> void :
	top_buttons.pressed.connect(_on_top_button_pressed)
	if ClockManager.last_tab:
		var container = get_node_or_null(ClockManager.last_tab)
		var button = get_node_or_null(ClockManager.last_button)
		if container:
			switch_to(container, button)
	else:
		switch_to( %PomodoroContainer, %PomodoroButton)
