extends MarginContainer

var alarm: ClockManager.Alarm
var button_enum_links: Dictionary[ClockManager.Weekday, Button] = {}

signal alarm_changed()

func update_ring_label() -> void :
	if !alarm.enabled:
		%RingLabel.text = "This alarm is disabled."
		return

	var hour_minute = alarm.get_local_hour_and_minute()

	if !ClockManager.is_using_24_hour_format() and hour_minute[0] == 0:
		hour_minute[0] = 12

	var days: String = ""
	var time: String = "%02d:%02d" % [hour_minute[0] if ClockManager.is_using_24_hour_format() else hour_minute[0] - 12 if hour_minute[0] > 12 else hour_minute[0], hour_minute[1]]
	var line: String = ""

	if alarm.ring_every_list.size() > 0:
		alarm.ring_every_list.sort()
		for weekday in alarm.ring_every_list:
			if alarm.ring_every_list.min() != weekday:
				days += ", "
			if alarm.ring_every_list.max() == weekday and alarm.ring_every_list.size() > 1:
				days += "and "

			days += ClockManager.get_weekday_string_from_enum(weekday)

		if ClockManager.is_using_24_hour_format():
			line = "This alarm will ring every {days} at {time}".format({"days": days, "time": time})
		else:
			line = "This alarm will ring every {days} at {time} {convention}".format({"days": days, "time": time, "convention": ClockManager.Convention.find_key(alarm.convention)})

	else:
		var local_date_dict = Time.get_datetime_dict_from_system()
		var local_ring_date_dict = Time.get_datetime_dict_from_unix_time(int(ClockManager.utc_unix_to_local_unix(alarm.target_ring_unix_time)))
		if local_date_dict.day != local_ring_date_dict.day:
			days = "tomorrow"
		else:
			days = "today"

		if ClockManager.is_using_24_hour_format():
			line = "This alarm will ring {days} at {time}".format({"days": days, "time": time})
		else:
			line = "This alarm will ring {days} at {time} {convention}".format({"days": days, "time": time, "convention": ClockManager.Convention.find_key(alarm.convention)})



	%RingLabel.text = line
	alarm_changed.emit()

func _on_kill_button_pressed() -> void :
	ClockManager.remove_alarm(alarm)
	alarm_changed.emit()
	queue_free()

func _on_name_changed(new_name: String) -> void :
	alarm.name = new_name
	alarm_changed.emit()

func _on_hour_minute_changed(_new_number: int) -> void :
	var hour_minute: Array[int] = []

	if ClockManager.is_using_24_hour_format():
		hour_minute = [
			clampi( %HourSpinbox.get_number() - 1, 0, 23), 
			clampi( %MinuteSpinbox.get_number(), 0, 59)
		]

	else:
		var offset = 12 if alarm.convention == ClockManager.Convention.PM else 0
		hour_minute = [
			clampi(posmod( %HourSpinbox.get_number(), 12) + offset, 0, 23), 
			clampi( %MinuteSpinbox.get_number(), 0, 59)
		]

	alarm.apply_local_hour_and_minute_to_ring_time(hour_minute)
	update_ring_label()

func _on_weekday_button_toggled(toggled_on: bool, weekday: ClockManager.Weekday) -> void :

	if toggled_on:
		if !alarm.ring_every_list.has(weekday):
			alarm.ring_every_list.append(weekday)
	else:
		var index = alarm.ring_every_list.find(weekday)
		if index != -1:
			alarm.ring_every_list.remove_at(index)

	_on_hour_minute_changed(0)

func _on_convention_selected(index: int) -> void :
	alarm.convention = index as ClockManager.Convention
	_on_hour_minute_changed(0)

func _on_enable_disable(_is_enabled: bool) -> void :
	if %ToggleBox.toggled == _is_enabled:
		alarm_changed.emit()
		return
	%ToggleBox.toggled = _is_enabled
	update_ring_label()

func _on_enable_toggled(_is_toggled: bool) -> void :
	if alarm.enabled == _is_toggled:
		return
	alarm.enabled = _is_toggled
	_on_hour_minute_changed(0)


func _ready() -> void :
	%Namer.text_changed.connect(_on_name_changed)
	button_enum_links[ClockManager.Weekday.Sunday] = %Sun
	button_enum_links[ClockManager.Weekday.Monday] = %Mon
	button_enum_links[ClockManager.Weekday.Tuesday] = %Tues
	button_enum_links[ClockManager.Weekday.Wednesday] = %Wed
	button_enum_links[ClockManager.Weekday.Thursday] = %Thurs
	button_enum_links[ClockManager.Weekday.Friday] = %Fri
	button_enum_links[ClockManager.Weekday.Saturday] = %Sat

	for weekday in button_enum_links:
		var button: Button = button_enum_links.get(weekday)
		if alarm:
			button.button_pressed = alarm.ring_every_list.has(weekday)
		button.toggled.connect(_on_weekday_button_toggled.bind(weekday))

	if !alarm:

		alarm = ClockManager.Alarm.new()
		ClockManager.call_deferred("add_alarm", alarm)


	else:
		%Namer.text = alarm.name




	%ConventionOption.selected = int(alarm.convention)
	%ToggleBox.toggled = alarm.enabled

	var hour_minute = alarm.get_local_hour_and_minute()
	if !ClockManager.is_using_24_hour_format() and hour_minute[0] == 0:
		hour_minute[0] = 12
	var offset = 12 if alarm.convention == ClockManager.Convention.PM else 0
	%HourSpinbox.line_edit.text = str(hour_minute[0]) if ClockManager.is_using_24_hour_format() else str(hour_minute[0] - offset if hour_minute[0] > 12 else hour_minute[0])
	%MinuteSpinbox.line_edit.text = str(hour_minute[1])
	update_ring_label()

	%ConventionOption.item_selected.connect(_on_convention_selected)
	%HourSpinbox.number_changed.connect(_on_hour_minute_changed)
	%MinuteSpinbox.number_changed.connect(_on_hour_minute_changed)
	%ToggleBox.on_toggled.connect(_on_enable_toggled)
	alarm.on_enable_disable.connect(_on_enable_disable)
