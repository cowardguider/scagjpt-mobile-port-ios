class_name CustomSpinbox extends HBoxContainer

@onready var line_edit: LineEdit = $LineEdit
@export var is_24_hours: bool = false
@export var is_minute: bool = false
var old_text: String = ""
var old_number: int = 0
var _regex = RegEx.new()
signal number_changed(new_number: int)

func get_number() -> int:
	return int(line_edit.text)

func _button_pressed(up: bool) -> void :
	var new_number = get_number() + (1 if up else -1)
	if new_number == -1: new_number = 59
	line_edit.text = str(new_number)
	_on_line_edit_text_changed(line_edit.text)


func _ready() -> void :
	_regex.compile("^[0-9]*$")
	%UpButton.pressed.connect(_button_pressed.bind(true))
	%DownButton.pressed.connect(_button_pressed.bind(false))


func _on_line_edit_text_changed(new_text: String) -> void :
	if _regex.search(new_text):
		var new_number = get_number()

		if is_minute:
			new_number = posmod(new_number, 60)
		else:
			if is_24_hours:
				new_number = Util.posmodoff(new_number, 24)
			else:
				new_number = Util.posmodoff(new_number, 12)
		new_text = str(new_number)

		line_edit.text = new_text
		old_text = new_text
		if new_number != old_number:
			old_number = new_number
			number_changed.emit(new_number)
	else:
		line_edit.text = old_text


	line_edit.caret_column = line_edit.text.length()
