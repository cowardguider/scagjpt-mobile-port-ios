extends MarginContainer

@export var type_group: ButtonGroup

func refresh_start_button():
	if ClockManager.pomo_running:
		%StartButton.text = "Stop"
	else:
		%StartButton.text = "Start"

func switch_to(type: ClockManager.PomoType):
	match type:
		ClockManager.PomoType.POMO:
			%TypeLabel.text = "Pomodoro"
		ClockManager.PomoType.BREAK:
			%TypeLabel.text = "Break"
		ClockManager.PomoType.LONG_BREAK:
			%TypeLabel.text = "Long Break"

	if type != ClockManager.pomo_current_type or ClockManager.pomo_elapsed == 0:
		ClockManager.switch_pomo_type(type)

	refresh_start_button()

func _on_top_button_pressed(button: BaseButton) -> void :
	match button.name:
		"PomodoroButton":
			switch_to(ClockManager.PomoType.POMO)
		"BreakButton":
			switch_to(ClockManager.PomoType.BREAK)
		"LongBreakButton":
			switch_to(ClockManager.PomoType.LONG_BREAK)

func _on_start_button_pressed() -> void :
	if ClockManager.pomo_running:
		ClockManager.stop_pomo()
	else:
		ClockManager.start_pomo()
	refresh_start_button()

func _on_pomo_ring(_type: ClockManager.PomoType) -> void :
	refresh_start_button()
	ClockManager.switch_pomo_type(ClockManager.pomo_current_type)


func _ready() -> void :
	ClockManager.on_pomo_ring.connect(_on_pomo_ring)
	type_group.pressed.connect(_on_top_button_pressed)
	switch_to(ClockManager.pomo_current_type)


func _process(_delta: float) -> void :
	if visible:
		if Globals.character.state == CharacterWorker.States.MENU_MODE:
			%TypeButtons.visible = true
			%MainButtons.visible = true
		else:
			%TypeButtons.visible = false
			%MainButtons.visible = false

		var minutes = int(ClockManager.pomo_elapsed / 60) % 60
		var seconds = int(ClockManager.pomo_elapsed) % 60

		%Minutes.text = "%02d" % [minutes]
		%Seconds.text = "%02d" % [seconds]
