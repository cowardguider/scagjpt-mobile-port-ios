@tool
extends VBoxContainer

@export var type: String = "TBD":
	set(new_value):
		type = new_value
		_update_type_label()
@export var number: String = "00":
	set(new_value):
		number = new_value
		_update_number_label()



func _update_type_label() -> void :
	var _type_label = get_node_or_null("%TypeLabel")
	if !_type_label: return
	_type_label.text = type

func _update_number_label() -> void :
	var _number_label = get_node_or_null("%NumberLabel")
	if !_number_label: return
	_number_label.text = number
