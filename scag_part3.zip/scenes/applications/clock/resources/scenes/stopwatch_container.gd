extends MarginContainer

var _last_save = 0

func add_lap(lap_number: int, elapsed: float) -> void :
	var label = Label.new()
	var days = str(int(elapsed / 60 / 60 / 60))
	var hours = str(int(elapsed / 60 / 60) % int(24))
	var minutes = str(int(elapsed / 60) % int(60))
	var seconds = str(int(elapsed) % int(60))
	var milliseconds = str(int((elapsed - int(elapsed)) * 100))

	days = "0" + days if days.length() == 1 else days
	hours = "0" + hours if hours.length() == 1 else hours
	minutes = "0" + minutes if minutes.length() == 1 else minutes
	seconds = "0" + seconds if seconds.length() == 1 else seconds
	milliseconds = "0" + milliseconds if milliseconds.length() == 1 else milliseconds

	var stringy = ""
	stringy = "{0}:{1}.{2}".format([minutes, seconds, milliseconds])
	if days != "00":
		stringy = "{0}:{1}:".format([days, hours]) + stringy
	elif hours != "00":
		stringy = "{0}:".format([hours]) + stringy

	stringy = "Lap {0} - ".format([lap_number]) + stringy

	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.text = stringy
	%LapContainer.add_child(label)
	%LapContainer.move_child(label, 0)


func refresh_buttons():
	if ClockManager.stopwatch_running:
		%ButtonLeft.text = "Lap"
		%ButtonRight.text = "Stop"
	else:
		%ButtonLeft.text = "Reset"
		%ButtonRight.text = "Start"

func _on_button_left_pressed() -> void :
	if ClockManager.stopwatch_running:
		var data = ClockManager.lap()
		add_lap(data[0], data[1])
	else:
		ClockManager.reset_stopwatch()
		for label in %LapContainer.get_children():
			label.queue_free()


func _on_button_right_pressed() -> void :
	if ClockManager.stopwatch_running:
		ClockManager.stop_stopwatch()
	else:
		ClockManager.start_stopwatch()
	refresh_buttons()


func _ready() -> void :
	refresh_buttons()
	for elapsed in ClockManager.stopwatch_lap_storage:
		var i = ClockManager.stopwatch_lap_storage.find(elapsed)
		add_lap(i + 1, elapsed)


func _process(delta: float) -> void :
	_last_save += delta
	if _last_save > 25:
		_last_save = 0
		ClockManager.save_stopwatch_data()

	if visible:





		var days = int(ClockManager.stopwatch_elapsed / 60 / 60 / 60)
		var hours = int(ClockManager.stopwatch_elapsed / 60 / 60) % 24
		var minutes = int(ClockManager.stopwatch_elapsed / 60) % 60
		var seconds = int(ClockManager.stopwatch_elapsed) % 60
		var milliseconds = int((ClockManager.stopwatch_elapsed - int(ClockManager.stopwatch_elapsed)) * 100)
		if days != 0:
			%Days.visible = true
			%Hours.visible = true
			%Minutes.visible = true
			%Seconds.visible = false
			%Milliseconds.visible = false
		elif hours != 0:
			%Days.visible = false
			%Hours.visible = true
			%Minutes.visible = true
			%Seconds.visible = true
			%Milliseconds.visible = false
		else:
			%Days.visible = false
			%Hours.visible = false
			%Minutes.visible = true
			%Seconds.visible = true
			%Milliseconds.visible = true

		%Days.number = "%02d" % [days]
		%Hours.number = "%02d" % [hours]
		%Minutes.number = "%02d" % [minutes]
		%Seconds.number = "%02d" % [seconds]
		%Milliseconds.number = "%02d" % [milliseconds]
