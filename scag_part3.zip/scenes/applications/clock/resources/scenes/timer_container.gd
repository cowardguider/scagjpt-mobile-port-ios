extends MarginContainer

const ALARM_CONTAINER = preload("uid://nbtfw81sxdpy")

func create_alarm_display(alarm: ClockManager.Alarm = null) -> void :
	var alarm_container = ALARM_CONTAINER.instantiate()
	alarm_container.alarm = alarm
	print("assigning this alarm because its a thing that exists!")
	%ContentContainer.add_child(alarm_container)
	alarm_container.alarm_changed.connect(refresh_next_ring)

func refresh_next_ring() -> void :
	var alarms: Array[ClockManager.Alarm] = ClockManager.get_alarms()
	alarms = alarms.filter( func(alarm: ClockManager.Alarm): return alarm.enabled)
	alarms.sort_custom( func(a, b): return a.target_ring_unix_time < b.target_ring_unix_time)
	var next_alarm: ClockManager.Alarm = alarms.front() if !alarms.is_empty() else null
	if next_alarm:
		var hour_minute = next_alarm.get_local_hour_and_minute()
		var time: String = "%02d:%02d" % [hour_minute[0] if ClockManager.is_using_24_hour_format() else hour_minute[0] - 12 if hour_minute[0] > 12 else hour_minute[0], hour_minute[1]]
		var alarm_name: String = "" if next_alarm.name.is_empty() else " %s" % next_alarm.name
		var line: String

		if ClockManager.is_using_24_hour_format():
			line = "Your next alarm{alarm_name} will ring at {time}".format({"alarm_name": alarm_name, "time": time})
		else:
			line = "Your next alarm{alarm_name} will ring at {time} {convention}".format({"alarm_name": alarm_name, "time": time, "convention": ClockManager.Convention.find_key(next_alarm.convention)})

		var now_dict = Time.get_datetime_dict_from_system()
		var ring_time_dict = Time.get_datetime_dict_from_unix_time(ClockManager.utc_unix_to_local_unix(next_alarm.target_ring_unix_time))

		if now_dict.day != ring_time_dict.day:
			line += " on {weekday}".format({"weekday": ClockManager.get_weekday_string_from_enum(ring_time_dict.weekday as ClockManager.Weekday)})

		%NextRingLabel.text = line
	else:
		%NextRingLabel.text = "You have no alarms! Add one using the button below."


func _ready() -> void :
	for alarm in ClockManager.get_alarms():
		create_alarm_display(alarm)

	refresh_next_ring()
	ClockManager.on_alarm_ring.connect( func(_alarm): refresh_next_ring())

func _on_add_alarm_button_pressed() -> void :
	create_alarm_display()
	call_deferred("refresh_next_ring")
