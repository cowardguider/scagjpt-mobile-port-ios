@tool
class_name AppBase extends Control

@export_tool_button("Insert TopBar") var insert_topbar = _insert_top_bar_callback

var _tween: Tween
var _audio_stream: AudioStreamPlayer = AudioStreamPlayer.new()
const MAXIMIZE_SFX = preload("uid://ckwhhvd4nty6g")
const MINIMIZE_SFX = preload("uid://fqfhg3l77tpg")

func _insert_top_bar_callback() -> void :
	var TOP_BAR: PackedScene = load("uid://cc6i553frlu8f")
	var scene = TOP_BAR.instantiate()
	add_child(scene)
	scene.owner = get_tree().edited_scene_root

func _notification(what: int) -> void :
	if what == NOTIFICATION_READY:
		if Engine.is_editor_hint(): return
		offset_transform_scale = Vector2(0.9, 0)
		_tween = create_tween()
		_tween.set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_BACK)
		_tween.tween_property(self, "offset_transform_scale", Vector2(1, 1), 0.2)
		_tween.play()
		_audio_stream.bus = "UI"
		add_child(_audio_stream)
		_audio_stream.stream = MAXIMIZE_SFX
		_audio_stream.play()
	if what == NOTIFICATION_ENTER_TREE:
		custom_minimum_size = Vector2(1175, 946)
		set_anchors_preset(Control.PRESET_CENTER)
		clip_contents = true
		offset_transform_enabled = true
		theme = preload("uid://dc36qlqxw4dmr")
		if Engine.is_editor_hint():
			position = Vector2(372.5, 67)
		else:
			position = Vector2.ZERO

func close(dont_destroy: bool = false) -> void :
	propagate_call("set_mouse_filter", [Control.MOUSE_FILTER_IGNORE])
	if _tween: _tween.kill()
	_tween = create_tween()
	_tween.set_ease(Tween.EASE_IN).set_trans(Tween.TRANS_SINE)
	_tween.tween_property(self, "offset_transform_scale", Vector2(0.9, 0), 0.15)
	_tween.play()
	_audio_stream.stream = MINIMIZE_SFX
	_audio_stream.play()
	await _tween.finished
	if !dont_destroy: queue_free()
