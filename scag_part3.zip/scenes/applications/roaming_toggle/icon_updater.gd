extends Node

const OFF = preload("uid://bvr43qsyn4cgn")
const ON = preload("uid://cmyciscccyei1")

var tracked_state = false

func _process(_delta: float) -> void :
	if tracked_state != Globals.character.roaming_enabled:
		tracked_state = Globals.character.roaming_enabled
		$"..".app_icon = ON if Globals.character.roaming_enabled else OFF
