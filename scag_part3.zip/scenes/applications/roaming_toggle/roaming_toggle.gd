extends Node

const APP_DATA: AppData = preload("uid://bwym30nc4ra8h")


func _ready() -> void :
	Globals.character.roaming_enabled = !Globals.character.roaming_enabled
	get_parent().queue_free()
