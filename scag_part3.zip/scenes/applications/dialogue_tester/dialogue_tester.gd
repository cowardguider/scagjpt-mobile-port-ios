extends Node

func create_button(text: String, sequence: DialogueSequence):
	var button = Button.new()
	%List.add_child(button)
	button.text = text
	button.button_up.connect(_play_dialogue.bind(sequence))

func _ready() -> void :
	for dialogue_path in DialogueManager.get_all_sequences():
		var resource = DialogueManager.load_sequence_from_path(dialogue_path)

		if resource is DialogueSequence:
			create_button(dialogue_path, DialogueManager.load_sequence_from_path(dialogue_path))
		elif resource is DialogueCollection:
			var all_sequences = resource.get_all_as_sequence()
			for sequence in all_sequences:
				var index = all_sequences.find(sequence)
				create_button(dialogue_path + " (%s)" % index, sequence)

func _play_dialogue(sequence: DialogueSequence) -> void :
	Globals.character.set_state(CharacterWorker.States.IDLE)
	await Util.wait(0.25)
	DialogueManager.play_sequence(sequence)

func _on_close_button_pressed() -> void :
	get_parent().close()
