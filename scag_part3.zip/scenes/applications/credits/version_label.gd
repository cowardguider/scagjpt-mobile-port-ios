extends Label



func _ready() -> void :
	text = "Version %s" % ProjectSettings.get_setting_with_override("application/config/version")
