extends Node

var credits_path = "user://credits.txt"
var internal_path = "res://scenes/applications/credits/credits.txt"

func _ready() -> void :
	%music.play()

func _on_close_button_pressed() -> void :
	get_parent().close()
	%music.stop()

func _process(delta: float) -> void :
	if Globals.is_media_player_showing or Globals.character.state != CharacterWorker.States.MENU_MODE:
		%music.stream_paused = true
	else:
		%music.stream_paused = false
