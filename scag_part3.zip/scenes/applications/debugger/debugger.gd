extends Node

func _close():
	get_parent().close()

func _ready() -> void :
	%TitleBar.get_node("%CloseButton").pressed.connect(_close)

	for key in CharacterWorker.States:
		var state = CharacterWorker.States.get(key)
		%StateDropdown.add_item(key, state as int)
		if state == Globals.character.state:
			%StateDropdown.select(state as int)

	%SquareCircleLineEdit.text = str(UserConfig.get_value("SquareAndCircleGame", "counter", 0))
	%StateDropdown.item_selected.connect( func(new_index: CharacterWorker.States): Globals.character.set_state(new_index))
	Globals.character.state_changed.connect( func(new_state: CharacterWorker.States, _previous_state: CharacterWorker.States): %StateDropdown.selected = new_state as int)



func _on_square_circle_line_edit_text_changed(new_text: String) -> void :
	var number = int(new_text)
	if number != null:
		UserConfig.set_value("SquareAndCircleGame", "counter", number)


func _on_ring_alarm_button_pressed() -> void :
	await Util.wait(2)
	Globals.character.get_node("JumpscareController").jumpscare(0, 0)
