class_name DialogueWindow extends Window

const DIALOGUE_OFFSET: float = 0.2
const BOTTOM_DIALOGUE_OFFSET: float = 0.4
const TARGET_WINDOW_OFFSET: int = 10

@export var target_window: DialogueWindow
@onready var animation_player: AnimationPlayer = $AnimationPlayer
@onready var label: RichTextLabel = %Label

var is_waiting_to_continue: bool = false
var input_type: Dialogue.InputType = Dialogue.InputType.NONE
var is_going_downward: bool = false



func _ready() -> void :
	var dialogue_boxes = get_tree().get_nodes_in_group("DialogueBox")
	if dialogue_boxes.size() <= 1: return
	var found_box = dialogue_boxes.get(dialogue_boxes.size() - 2)
	if found_box != self:
		target_window = found_box



func _process(delta: float) -> void :
	set_input_as_handled()


	size = Vector2i.ONE
	%ContinueContainer.visible = input_type == Dialogue.InputType.CLICK and is_waiting_to_continue

	if target_window:
		var screen_position: Vector2i = DisplayServer.window_get_position(target_window.get_window_id())

		is_going_downward = false
		var screen_rect = DisplayServer.screen_get_usable_rect(Util.get_current_screen())
		var window_size = DisplayServer.window_get_size(get_window_id())
		if target_window.is_going_downward == true or screen_position.y <= screen_rect.position.y + float(window_size.y):
			is_going_downward = true

		else:
			is_going_downward = false



		if target_window.is_going_downward:
			var target_window_size = DisplayServer.window_get_size(target_window.get_window_id())
			DisplayServer.window_set_position(Vector2i(Vector2(DisplayServer.window_get_position(get_window_id())).lerp(
				screen_position + Vector2i(target_window_size.x / 2 - window_size.x / 2, TARGET_WINDOW_OFFSET + window_size.y), delta * 10)
			), get_window_id())



		else:
			var target_window_size = DisplayServer.window_get_size(target_window.get_window_id())
			DisplayServer.window_set_position(Vector2i(Vector2(DisplayServer.window_get_position(get_window_id())).lerp(
				screen_position + Vector2i(target_window_size.x / 2 - window_size.x / 2, - TARGET_WINDOW_OFFSET - window_size.y), delta * 10)
			), get_window_id())



	else:
		if !Globals.character: return
		var aabb = Globals.character.rig.get_bounding_box()
		var bounding_box = Globals.character.rig.global_transform * aabb
		var top_left = bounding_box.get_center() + Vector3(0, bounding_box.size.y + DIALOGUE_OFFSET, 0) / 2
		var window_position = Globals.camera.unproject_position(top_left) * get_viewport().get_screen_transform().get_scale()
		var screen_position = DisplayServer.window_get_position(get_tree().root.get_window_id()) + Vector2i(window_position)
		var screen_rect = DisplayServer.screen_get_usable_rect(Util.get_current_screen())
		is_going_downward = false

		if Globals.character.state == CharacterWorker.States.MENU_MODE:
			var center = bounding_box.get_center() + Vector3(bounding_box.size.x + BOTTOM_DIALOGUE_OFFSET, 0.4, 0) / 2
			window_position = Globals.camera.unproject_position(center) * get_viewport().get_screen_transform().get_scale()
			screen_position = DisplayServer.window_get_position(get_tree().root.get_window_id()) + Vector2i(window_position)
		elif screen_position.y <= screen_rect.position.y + float(size.y):
			var bottom_left = bounding_box.get_center() + Vector3(0, - bounding_box.size.y - BOTTOM_DIALOGUE_OFFSET, 0) / 2
			window_position = Globals.camera.unproject_position(bottom_left) * get_viewport().get_screen_transform().get_scale()
			screen_position = DisplayServer.window_get_position(get_tree().root.get_window_id()) + Vector2i(window_position)
			is_going_downward = true

		var window_size = DisplayServer.window_get_size(get_window_id())
		if screen_position.x <= screen_rect.position.x + float(window_size.x) / 2:
			screen_position += Vector2i(int(float(window_size.x) / 2), 0)
		elif screen_position.x >= screen_rect.position.x + screen_rect.size.x - float(window_size.x) / 2:
			screen_position -= Vector2i(int(float(window_size.x) / 2), 0)




		DisplayServer.window_set_position(Vector2i(Vector2(DisplayServer.window_get_position(get_window_id())).lerp(ScreenBounds.get_position(screen_position, Vector2(0.5, 1), self), delta * 10)), get_window_id())
