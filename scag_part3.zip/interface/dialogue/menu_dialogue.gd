extends PanelContainer

@onready var label: RichTextLabel = %Label
@onready var animation_player: AnimationPlayer = $AnimationPlayer

var is_waiting_to_continue: bool = false
var input_type: Dialogue.InputType = Dialogue.InputType.NONE

func _process(_delta: float) -> void :


	if input_type == Dialogue.InputType.CLICK:
		%ContinueContainer.visible = true
		%ContinueContainer.modulate = Color(1.0, 1.0, 1.0, 1.0) if is_waiting_to_continue else Color(1.0, 1.0, 1.0, 0.0)
	else:
		%ContinueContainer.visible = false
