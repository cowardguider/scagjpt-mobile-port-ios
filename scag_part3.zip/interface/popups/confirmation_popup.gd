@tool
extends AppBase

@onready var title_bar: Control = %TitleBar
signal on_confirmation(confirmed: bool)









func _on_option_chosen(confirmed: bool) -> void :
	on_confirmation.emit(confirmed)
	close()


func _ready() -> void :
	if Engine.is_editor_hint(): return
	print("hi squire")

	var close_button: Button = %TitleBar.get_node("%CloseButton")
	close_button.pressed.connect(_on_option_chosen.bind(false))
	%NoButton.pressed.connect(_on_option_chosen.bind(false))
	%YesButton.pressed.connect(_on_option_chosen.bind(true))
