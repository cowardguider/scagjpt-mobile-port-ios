class_name FaceMenu extends Control



const APP_RESOURCE_PATH: String = "res://resources/apps/"
const DEBUG_APP_RESOURCE_PATH: String = "res://!dev/resources/debug_apps/"

@onready var static_transition: TextureRect = %StaticTransition

var apps: Array[AppData] = []
var _registered_apps: Dictionary[AppData, AppIcon] = {}
var is_in_menu = false
var _static_tween: Tween

func get_app_icon(app: AppData) -> AppIcon:
	return %AppList.get_node(app.name)

func add_app_to_registry(app: AppData) -> AppIcon:
	apps.append(app)
	var scene: PackedScene = load(app.app_icon_path)
	var icon: AppIcon = scene.instantiate()
	icon.name = tr(app.name)
	icon.visible = !app.hidden
	%AppList.add_child(icon)

	var button: Button = icon.get_node_or_null("Button")
	button.pressed.connect(_app_button_pressed.bind(app))
	return icon

func get_apps_in_directory(file_path: String) -> Array[AppData]:
	if !DirAccess.dir_exists_absolute(file_path):
		push_warning("[face_menu.gd]: %s is not a valid file path!")
		return []

	var directory = DirAccess.open(file_path)

	if directory == null:
		push_error("[face_menu.gd]: Couldn't open apps directory.")
		return []
	var layout: Array[AppData] = []

	for file_name in directory.get_files():
		if file_name.contains(".tres"):

			if file_name.contains(".remap"):
				file_name = file_name.replace(".remap", "")
			var app: AppData = load(file_path + file_name)
			print("[face_menu.gd]: loading %s" % app.name)
			_registered_apps[app] = add_app_to_registry(app)
			layout.append(app)

	return layout

func initialize_apps():
	var layout = get_apps_in_directory(APP_RESOURCE_PATH)
	if OS.has_feature("editor"):
		layout.append_array(get_apps_in_directory(DEBUG_APP_RESOURCE_PATH))

	layout.sort_custom( func(a, b): return a.layout_order < b.layout_order)
	for app_data in _registered_apps:
		var app_icon = _registered_apps[app_data]
		%AppList.move_child(app_icon, layout.find(app_data))
	print("[face_menu.gd]: Successfully loaded apps.")

func play_transition() -> void :
	if _static_tween: _static_tween.kill()
	Globals.character.get_node("SFX/trans").play()
	static_transition.visible = true
	static_transition.modulate = Color.WHITE
	_static_tween = Util.icbin_tweenService(static_transition, "modulate", Color.TRANSPARENT, 0.5, Tween.TRANS_SINE, Tween.EASE_OUT)

func _app_button_pressed(app: AppData):
	print("[face_menu.gd]: " + app.name + " was pressed!")
	var scene: PackedScene = load(app.menu_scene_path)
	var loaded = scene.instantiate()
	Globals.menu_container.add_child(loaded)
	loaded.position = Vector2.ZERO

func _close_button_pressed():
	Globals.character.set_state(CharacterWorker.States.IDLE)

func _on_roaming_toggle_on_toggled(_is_toggled: bool) -> void :
	GameSettings.set_setting_and_update("SCAG_ROAMING", !GameSettings.get_setting("SCAG_ROAMING", false))

func _on_setting_changed(key: String, value: bool) -> void :
	if key == "SCAG_ROAMING":
		%RoamingToggle.set_toggled_no_signal(value)
	if key == "CRT_EFFECT":
		%CRTShader.visible = value


func _input(event: InputEvent) -> void :
	if event is InputEventMouseButton:
		if event.button_index == 1:
			if event.pressed:
				$MouseDownSFX.play()
			else:
				$MouseUpSFX.play()


func _ready() -> void :
	Globals.face_menu = self
	Globals.menu_container = get_parent()
	static_transition.call_deferred("reparent", Globals.menu_container)

	%RoamingToggle.toggled = GameSettings.get_setting("SCAG_ROAMING", false)
	%CRTShader.visible = GameSettings.get_setting("CRT_EFFECT", true)

	initialize_apps()
	%RoamingToggle.on_toggled.connect(_on_roaming_toggle_on_toggled)
	GameSettings.on_setting_changed.connect(_on_setting_changed)
	%TitleBar.get_node("%CloseButton").pressed.connect(_close_button_pressed)

	print("lala")
	%WelcomeLabel.text = "[font size=50]Hello, [font size=40][wave]%s!" % await SteamManager.get_username()
	%ProfilePicture.texture = await SteamManager.get_profile_pic()
