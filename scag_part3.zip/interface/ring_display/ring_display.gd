class_name RingDisplay extends Node

func play() -> void :
	%Music.play()
	Globals.menu_mode_toggle_disabled.add(10, true)
	pass

func close() -> void :
	Globals.menu_mode_toggle_disabled.remove(10)
	get_parent().close()
