@tool
@icon("uid://cb1bpusj6hfhv")
class_name AppIcon extends PanelContainer

@export_group("Application Config")
@export var app_name: String = "The Square & Circle Show The Game":
	set(new_property):
		app_name = new_property
		_update_properties()
@export var app_icon: Texture2D = preload("uid://cb1bpusj6hfhv"):
	set(new_property):
		app_icon = new_property
		_update_properties()

func _update_properties():


	var title_label = get_node_or_null("%Title")
	if title_label:
		title_label.text = tr(app_name)

	var icon_tex = get_node_or_null("%Icon")
	if icon_tex:
		icon_tex.texture = app_icon
