extends Window

const DIALOGUE_OFFSET: float = 0.6
var spring: SpringDamper = SpringDamper.new(Vector2.ZERO, Vector2.ZERO, 16, 0.5)
@onready var animation_player: AnimationPlayer = $AnimationPlayer
var _mouse_inside: bool = false
func _input(event: InputEvent) -> void :
	if _mouse_inside and event.is_action_released("hold") and !gui_disable_input:
		animation_player.play("out")
		Globals.character.add_poke_block_time(0.2)
		%CloseLabel.text = "Byebye!!"

func _exit_tree() -> void :
	print("bye brih")
	Globals.poke_enabled.call_deferred("remove", 8)
	Globals.drag_enabled.call_deferred("remove", 8)


func _ready() -> void :
	spring.pos = Vector2(DisplayServer.window_get_position(0))
	animation_player.play("in")

func _process(delta: float) -> void :
	size = Vector2i.ONE
	if !Globals.character: return
	var aabb = Globals.character.rig.get_bounding_box()
	var bounding_box = Globals.character.rig.global_transform * aabb
	var screen_rect = DisplayServer.screen_get_usable_rect(Util.get_current_screen())
	var center = bounding_box.get_center() + Vector3(bounding_box.size.x + DIALOGUE_OFFSET, 0, 0) / 2
	var window_position = Globals.camera.unproject_position(center) * get_viewport().get_screen_transform().get_scale()
	var screen_position = DisplayServer.window_get_position(get_tree().root.get_window_id()) + Vector2i(window_position)

	var window_size = DisplayServer.window_get_size(get_window_id())


	if screen_position.x - float(window_size.x) / 2 >= screen_rect.position.x + screen_rect.size.x / 2 + float(window_size.x) / 2:
		center = bounding_box.get_center() - Vector3(bounding_box.size.x + DIALOGUE_OFFSET, 0, 0) / 2
		window_position = Globals.camera.unproject_position(center) * get_viewport().get_screen_transform().get_scale()
		screen_position = DisplayServer.window_get_position(get_tree().root.get_window_id()) + Vector2i(window_position)

	var target_position = Vector2i(ScreenBounds.get_position(screen_position, Vector2(0.5, 1), self))
	DisplayServer.window_set_position(Vector2i(spring.update_spring_damper(Vector2(target_position), delta)), get_window_id())



func _on_mouse_entered() -> void :
	_mouse_inside = true
	Globals.poke_enabled.add(8, false)
	Globals.drag_enabled.add(8, false)

func _on_mouse_exited() -> void :
	_mouse_inside = false
	if !gui_disable_input:
		Globals.poke_enabled.remove(8)
		Globals.drag_enabled.remove(8)
