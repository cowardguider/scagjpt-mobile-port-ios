@tool
extends Node

@export_group("Topbar Config")
@export var title: String = "Scag.iso":
	set(new_property):
		title = new_property
		_update_properties()


func _update_properties():
	%TitleBar.text = title
