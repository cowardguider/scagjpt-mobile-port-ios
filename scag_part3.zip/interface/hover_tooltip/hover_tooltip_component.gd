class_name HoverTooltipComponent extends Node



const HOVER_TOOLTIP_SCENE: PackedScene = preload("uid://dkwholf0g20ex")

var _parent_node: Control
var _mouse_over: bool = false
var _hover_time: float = 0.0

var tooltip_container: PanelContainer
@export var appear_time: float = 0.1
@export_multiline() var hint: String = "TBD":
	set(new_value):
		hint = new_value
		if tooltip_container:
			tooltip_container.set_text(hint)
var is_showing_tooltip: bool = false:
	set(new_value):
		if new_value != is_showing_tooltip:
			is_showing_tooltip = new_value
			_set_tooltip_showing(is_showing_tooltip)
			return
		is_showing_tooltip = new_value


func _set_tooltip_showing(visible: bool) -> void :


	tooltip_container.set_state(visible)

func _on_mouse_state_changed(hovering: bool) -> void :
	_mouse_over = hovering

func _process(delta: float) -> void :




	if _mouse_over:
		if is_showing_tooltip: return
		_hover_time += delta
		if _hover_time > appear_time:
			is_showing_tooltip = true
	else:
		_hover_time = 0
		is_showing_tooltip = false





func _ready() -> void :
	_parent_node = get_parent()
	_parent_node.mouse_entered.connect(_on_mouse_state_changed.bind(true))
	_parent_node.mouse_exited.connect(_on_mouse_state_changed.bind(false))
	tooltip_container = HOVER_TOOLTIP_SCENE.instantiate()
	tooltip_container.visible = false
	add_child(tooltip_container)
	tooltip_container.set_text(hint)
