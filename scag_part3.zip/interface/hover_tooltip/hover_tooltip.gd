extends PanelContainer
@onready var animation_player: AnimationPlayer = $AnimationPlayer
@export var mouse_offset: Vector2 = Vector2(20, 20)
@export var bounds_offset: Vector2 = Vector2(5, 5)


func set_text(text: String) -> void :
	%RichTextLabel.text = text

func set_state(showing: bool) -> void :
	if showing:
		position = get_viewport().get_mouse_position()
		animation_player.play("in")
	else:
		animation_player.play("out")

func _ready() -> void :
	size = Vector2.ZERO

func _process(delta: float) -> void :
	if visible:
		var mouse_position = get_viewport().get_mouse_position()
		var target_position = mouse_position + mouse_offset
		var rectum = get_viewport_rect()

		var offset_x = maxf((target_position.x + size.x + bounds_offset.x) - rectum.size.x, 0)
		var offset_y = maxf((target_position.y + size.y + bounds_offset.y) - rectum.size.y, 0)

		position = position.lerp(target_position - Vector2(offset_x, offset_y), delta * 30)
