@tool
extends MarginContainer

@export var text: String = "I am a toggle box!":
	set(new_value):
		text = new_value
		refresh()

@export var toggled: bool = false:
	set(new_value):
		var old_value = toggled
		toggled = new_value
		if old_value != new_value and !_dont_emit:
			on_toggled.emit(new_value)
		refresh()

var _dont_emit = false

signal on_toggled(is_toggled: bool)

func set_toggled_no_signal(is_toggled: bool) -> void :

	_dont_emit = true
	toggled = is_toggled
	_dont_emit = false

func refresh():
	var label: Label = get_node_or_null("%Label")
	var check_box: AnimatedCheckButton = get_node_or_null("%CheckBox")

	if label:
		label.text = text

	if check_box:
		check_box.button_pressed = toggled



func _ready() -> void :
	var check_box: AnimatedCheckButton = get_node_or_null("%CheckBox")

	if check_box:
		check_box.toggled.connect( func(pressed: bool): toggled = pressed)
