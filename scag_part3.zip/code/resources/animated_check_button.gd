@tool
class_name AnimatedCheckButton
extends Button

@export var off_color: Color = Color("6f768fff")
@export var on_color: Color = Color("31458fff")

@export var checkbutton_base: CompressedTexture2D

@export var track_size: Vector2 = Vector2(70, 35):
	set(value):
		track_size = value
		custom_minimum_size = track_size
		queue_redraw()

@export var padding: float = 3.0:
	set(value):
		padding = value
		queue_redraw()

var _progress: float = 0.0:
	set(value):
		_progress = clampf(value, 0.0, 1.0)
		queue_redraw()

var _tween: Tween

func _init() -> void :
	toggle_mode = true
	focus_mode = Control.FOCUS_ALL
	text = ""
	flat = true

func _ready() -> void :
	custom_minimum_size = track_size
	_progress = 1.0 if button_pressed else 0.0
	toggled.connect(_on_toggled)

func _on_toggled(toggled_on: bool) -> void :
	_animate_to(1.0 if toggled_on else 0.0)

func _animate_to(target: float) -> void :
	if _tween: _tween.kill()

	_tween = create_tween()
	_tween.set_trans(Tween.TRANS_CUBIC)
	_tween.set_ease(Tween.EASE_OUT)
	_tween.tween_property(self, "_progress", target, 0.05)

func _draw() -> void :
	var center = Vector2(0, size.y / 2 - track_size.y / 2)
	var rect: Rect2 = Rect2(center, track_size)

	var knob_color = Color.GRAY.lerp(Color.WHITE, _progress)
	var bg_color = off_color.lerp(on_color, _progress)

	if disabled:
		bg_color *= Color(0.7, 0.7, 0.7)

	draw_texture_rect(checkbutton_base, rect, false, bg_color)

	var knob_radius: float = (track_size.y - padding * 2.0) * 0.5
	var left_x = padding + knob_radius
	var right_x = track_size.x - padding - knob_radius
	var knob_x = lerpf(left_x, right_x, _progress)
	var knob_center = Vector2(knob_x, track_size.y * 0.5 + center.y)

	draw_circle(knob_center, knob_radius, knob_color, true, -1.0, true)
