@icon("uid://dt1jb1i4f5t7x")
@tool
class_name AppData extends Resource

@export_group("Application Config")
@export var name: String = "TBD"
@export_file("*.tscn", "*.scn") var app_icon_path: String
@export_file("*.tscn", "*.scn") var menu_scene_path: String
@export var layout_order: int = 0
@export var hidden: bool = false

@export_group("Useful Buttons")

@export_tool_button("Open App Icon Scene", "Callable") var open_app_icon_scene_action: Callable = open_icon_scene
@export_tool_button("Open Menu Scene", "Callable") var open_menu_scene_action: Callable = open_menu_scene

const TARGET_APP_PATH = "res://scenes/applications/"













func open_scene(scene_path: String) -> void :
	var editor_interface = Engine.get_singleton("EditorInterface")
	if !editor_interface: return
	if !FileAccess.file_exists(scene_path):
		push_warning("No scene found named \"%s\", not opening!" % scene_path)
		return

	editor_interface.call_deferred("open_scene_from_path", scene_path)
	editor_interface.call_deferred("set_main_screen_editor", "2D")


func open_icon_scene() -> void :
	open_scene(app_icon_path)

func open_menu_scene() -> void :
	open_scene(menu_scene_path)
