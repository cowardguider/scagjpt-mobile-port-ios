
class_name DialogueCollection extends Resource

@export var single_lines: Array[Dialogue] = []
@export var multi_lines: Array[DialogueSequence] = []

func pick_random_line() -> DialogueSequence:
	var sequence: DialogueSequence
	if Util.random_bool() or multi_lines.is_empty():
		var dialogue = single_lines.pick_random()
		sequence = DialogueSequence.new()
		sequence.sequence.append(dialogue)
	else:
		sequence = multi_lines.pick_random()

	return sequence

func get_all_as_sequence() -> Array[DialogueSequence]:
	var all_sequences: Array[DialogueSequence] = []

	for dialogue in single_lines:
		var sequence = DialogueSequence.new()
		sequence.sequence.append(dialogue)
		all_sequences.append(sequence)

	for sequence in multi_lines:
		all_sequences.append(sequence)

	return all_sequences
