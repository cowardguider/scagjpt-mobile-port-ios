
class_name DialogueSequence extends Resource


@export var sequence: Array[Dialogue] = []
@export var audio: AudioStream
