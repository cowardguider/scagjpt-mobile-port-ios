
class_name Dialogue extends Resource

enum InputType{NONE, CLICK, SCRIPTED}

@export_multiline var text: String = ""
@export var wait_time: float = 2
@export var type_speed: float = 0.02

@export var input_type: InputType = InputType.NONE
@export var dialogue_box_type: DialogueManager.BoxType = DialogueManager.BoxType.DEFAULT

@export var audio: AudioStream
