extends Node


var selection_scale: float = 0.09
var selection_offset: Vector2 = Vector2.ZERO
var _scale_priority = PriorityManager.new(selection_scale)
var _offset_priority = PriorityManager.new(selection_offset)
var _window_size_priority = PriorityManager.new(Globals.DEFAULT_WINDOW_SIZE)
var mouse_passthrough_enabled: PriorityManager = PriorityManager.new(true)
var scag_screen_bounds: Rect2 = Rect2(0, 0, 1, 1)
var bound_points: PackedVector2Array = []
var target_window_position: Vector2i = Vector2i.ZERO
var queued_new_screen: int = -1
var current_screen: int = 0
var _skip_positioning: bool = false


func set_mouse_space_scale(priority: int, value: float):
	_scale_priority.add(priority, value)

func clear_mouse_space_scale(priority: int):
	_scale_priority.remove(priority)

func set_mouse_space_offset(priority: int, value: Vector2):
	_offset_priority.add(priority, value)

func clear_mouse_space_offset(priority: int):
	_offset_priority.remove(priority)

func set_window_size(priority: int, value: Vector2i):
	_window_size_priority.add(priority, value)

func clear_window_size(priority: int):
	_window_size_priority.remove(priority)



func set_position(target_position: Vector2i, position_offset_ratio: Vector2 = Vector2.ZERO, target_window: Window = null):
	var window = target_window if target_window != null else get_tree().root


	var target_pos = target_position - Vector2i(
		floori(remap(position_offset_ratio.x, 0, 1, 0, window.size.x)), 
		floori(remap(position_offset_ratio.y, 0, 1, 0, window.size.y))
	)

	if target_window:
		DisplayServer.window_set_position(target_pos)

	else:
		target_window_position = target_pos


func set_position_raw(target_position: Vector2i):
	target_window_position = target_position



func get_position(target_position: Vector2i, position_offset_ratio: Vector2 = Vector2.ZERO, target_window: Window = null):
	var window = target_window if target_window != null else get_tree().root

	return target_position - Vector2i(
		floori(remap(position_offset_ratio.x, 0, 1, 0, window.size.x)), 
		floori(remap(position_offset_ratio.y, 0, 1, 0, window.size.y))
	)




func get_position_with_ratio(ratio: Vector2, position_offset_ratio: Vector2 = Vector2.ZERO, target_screen: int = Util.get_current_screen(), target_window: Window = null):
	var window = target_window if target_window != null else get_tree().root
	var screen_rect = DisplayServer.screen_get_usable_rect(target_screen)

	return Vector2i(
		floori(remap(ratio.x, 0, 1, screen_rect.position.x, screen_rect.position.x + screen_rect.size.x)), 
		floori(remap(ratio.y, 0, 1, screen_rect.position.y, screen_rect.position.y + screen_rect.size.y))
	) - Vector2i(
		floori(remap(position_offset_ratio.x, 0, 1, 0, window.size.x)), 
		floori(remap(position_offset_ratio.y, 0, 1, 0, window.size.y))
	)




func set_position_with_ratio(ratio: Vector2, position_offset_ratio: Vector2 = Vector2.ZERO, target_screen: int = Util.get_current_screen(), target_window: Window = null):
	var window = target_window if target_window != null else get_tree().root
	var screen_rect = DisplayServer.screen_get_usable_rect(target_screen)

	target_window_position = Vector2i(
		floori(remap(ratio.x, 0, 1, screen_rect.position.x, screen_rect.position.x + screen_rect.size.x)), 
		floori(remap(ratio.y, 0, 1, screen_rect.position.y, screen_rect.position.y + screen_rect.size.y))
	) - Vector2i(
		floori(remap(position_offset_ratio.x, 0, 1, 0, window.size.x)), 
		floori(remap(position_offset_ratio.y, 0, 1, 0, window.size.y))
	)

func get_random_screen_position(target_screen: int = Util.get_current_screen()) -> Vector2i:
	var screen_rect = DisplayServer.screen_get_usable_rect(target_screen)
	return Vector2i(
		randi_range(screen_rect.position.x, screen_rect.position.x + screen_rect.size.x), 
		randi_range(screen_rect.position.y, screen_rect.position.y + screen_rect.size.y)
	)

func _ready() -> void :
	process_priority = 3
	_scale_priority.priority_changed.connect(_on_scale_priority_changed)
	_offset_priority.priority_changed.connect(_on_offset_priority_changed)
	current_screen = get_window().current_screen

	_window_size_priority.priority_changed.connect(_on_window_size_priority_changed)
	get_tree().root.size_changed.connect(refresh)
	set_position_with_ratio(Vector2(0.5, 0.5), Vector2(0.5, 0.5))
	refresh()

func _on_scale_priority_changed(value: Variant, _priority: int) -> void :
	selection_scale = value

	refresh()


func _on_offset_priority_changed(value: Variant, _priority: int) -> void :
	selection_offset = value

	refresh()

func _on_window_size_priority_changed(value: Variant, _priority: int) -> void :

	get_window().size = value
	refresh()

func _process(_delta: float) -> void :
















	if queued_new_screen != -1 and !_skip_positioning:
		current_screen = queued_new_screen
		queued_new_screen = -1
		_skip_positioning = true

	if !_skip_positioning:
		DisplayServer.window_set_position(Util.clamp_to_target_screen_size(current_screen, target_window_position, true), 0)

	else:
		_skip_positioning = false


	Debugger.write("Clamped Position: %s" % get_window().position, "windowclamped")
	Debugger.write("Unclamped Position: %s" % target_window_position, "windowunclamped")
	Debugger.write("Window Size: %s" % get_window().size, "WindowSIze")
	Debugger.write("Window Size... 2!: %s" % DisplayServer.window_get_size(get_window().get_window_id()), "WindowSIze2")



	Debugger.write("Current Display: {0}".format([Util.get_current_screen()]), "CurrentScreen")


	Debugger.write("Mouse Passthrough Scale: {0} | {1}".format([_scale_priority.highest_priority, selection_scale]), "Mouse Passthrough Scale")
	Debugger.write("Mouse Passthrough Offset: {0} | {1}".format([_offset_priority.highest_priority, selection_offset]), "Mouse Passthrough Offset")






func refresh() -> void :
	if !mouse_passthrough_enabled.get_prioritized_value() or Globals.character == null:
		DisplayServer.window_set_mouse_passthrough([])
		return
	var _aabb = Globals.character.rig.get_bounding_box()

	var bounding_box: AABB = Globals.character.rig.global_transform * _aabb

	var top_left_position = bounding_box.get_center() + Vector3( - bounding_box.size.x - selection_scale, bounding_box.size.y + selection_scale, bounding_box.size.z) / 2
	var top_right_position = bounding_box.get_center() + Vector3(bounding_box.size.x + selection_scale, bounding_box.size.y + selection_scale, bounding_box.size.z) / 2
	var bottom_left_position = bounding_box.get_center() + Vector3( - bounding_box.size.x - selection_scale, - bounding_box.size.y - selection_scale, bounding_box.size.z) / 2
	var bottom_right_position = bounding_box.get_center() + Vector3(bounding_box.size.x + selection_scale, - bounding_box.size.y - selection_scale, bounding_box.size.z) / 2
	bound_points = [
		Util.clamp_to_window_size(get_viewport().get_camera_3d().unproject_position(top_left_position) + selection_offset) * get_viewport().get_screen_transform().get_scale(), 
		Util.clamp_to_window_size(get_viewport().get_camera_3d().unproject_position(bottom_left_position) + selection_offset) * get_viewport().get_screen_transform().get_scale(), 
		Util.clamp_to_window_size(get_viewport().get_camera_3d().unproject_position(bottom_right_position) + selection_offset) * get_viewport().get_screen_transform().get_scale(), 
		Util.clamp_to_window_size(get_viewport().get_camera_3d().unproject_position(top_right_position) + selection_offset) * get_viewport().get_screen_transform().get_scale(), 
	]



	scag_screen_bounds = Rect2(bound_points[0], bound_points[2])



	DisplayServer.window_set_mouse_passthrough(bound_points)
