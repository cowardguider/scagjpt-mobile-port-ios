extends Node




const SCAG_TALK_STREAM = preload("uid://dxgcmw6fhq1kc")
const DIALOGUE_WINDOW = preload("uid://b4ek4ob8otv44")
const MENU_DIALOGUE = preload("uid://dgogti477hngs")

var voice_box: AudioStreamPlayer3D
var running_dialogue: Array[RunningDialogue] = []

enum BoxType{NONE, DEFAULT, MENU_MODE}




class RunningDialogue:
	var window: Variant
	var sequence: DialogueSequence
	var current_box_type: BoxType = BoxType.NONE
	var string_format: Variant = {}
	var no_anim: bool = false
	var is_typing = false
	var skip = false
	signal on_continue()
	signal on_finished_typing()
	signal on_complete()

	func _init(init_sequence: DialogueSequence, init_no_anim: bool = false, init_string_format: Variant = {}) -> void :
		sequence = init_sequence
		no_anim = init_no_anim
		string_format = init_string_format
		DialogueManager.running_dialogue.append(self)

	func _type_text(text: String, type_speed: float) -> void :
		is_typing = true
		for i in text.length():
			if !skip:
				await Util.wait(type_speed)
			window.label.visible_characters = i + 1
			var current_letter = text[i]

			if current_letter == "." or current_letter == "!" or current_letter == "?" or current_letter == ",":
				if !skip:
					await Util.wait(0.25)

		is_typing = false
		skip = false

	func proceed() -> void :
		if is_typing:
			skip = true
		else:
			on_continue.emit()

	func run() -> void :

		print(current_box_type)

		var _is_showing = false
		for dialogue in sequence.sequence:

			if dialogue.dialogue_box_type != current_box_type:
				if window != null:
					window.animation_player.play("out")
				window = DialogueManager._create_dialogue_box(dialogue.dialogue_box_type)
				_is_showing = false
				current_box_type = dialogue.dialogue_box_type
			var text = tr(dialogue.text).format(string_format)
			window.label.text = text
			window.label.visible_characters = 0
			window.input_type = dialogue.input_type

			if !_is_showing:
				_is_showing = true
				window.animation_player.play("in")
				window.visible = true

			if DialogueManager.voice_box:
				if dialogue.audio != null:
					DialogueManager.voice_box.pitch_scale = 1
					DialogueManager.voice_box.stream = dialogue.audio
				else:
					DialogueManager.voice_box.pitch_scale = randf_range(0.95, 1.05)
					DialogueManager.voice_box.stream = SCAG_TALK_STREAM
				DialogueManager.voice_box.play()

			if Globals.character and !no_anim:
				ScreenBounds.set_mouse_space_scale(2, 0.15)
				ScreenBounds.set_mouse_space_offset(2, Vector2(15, -10))
				Globals.character.rig.set_is_talking(true)
			await _type_text(text, dialogue.type_speed)
			on_finished_typing.emit()

			if Globals.character and !no_anim:
				ScreenBounds.clear_mouse_space_scale(2)
				ScreenBounds.clear_mouse_space_offset(2)
				Globals.character.rig.set_is_talking(false)
			if dialogue.input_type != Dialogue.InputType.NONE:
				window.is_waiting_to_continue = true
				await on_continue
				window.is_waiting_to_continue = false
			else:
				await Util.wait(dialogue.wait_time)

			if sequence.sequence.rfind(dialogue) != sequence.sequence.size() - 1:
				window.label.visible_characters = 0
				await Util.wait(0.05)

		window.animation_player.play("out")
		on_complete.emit()
		var index = DialogueManager.running_dialogue.find(self)
		if index != -1:
			DialogueManager.running_dialogue.remove_at(index)

func _create_dialogue_box(box_type: BoxType = BoxType.DEFAULT) -> Variant:
	var window: Variant

	match box_type:
		BoxType.NONE:
			window = DIALOGUE_WINDOW.instantiate()
			window.visible = false

			get_tree().current_scene.add_child(window)
			window.set_deferred("position", DisplayServer.window_get_position(0) + DisplayServer.window_get_size() / 2)

		BoxType.DEFAULT:
			window = DIALOGUE_WINDOW.instantiate()
			window.visible = false

			get_tree().current_scene.add_child(window)
			window.set_deferred("position", DisplayServer.window_get_position(0) + DisplayServer.window_get_size() / 2)

		BoxType.MENU_MODE:
			window = MENU_DIALOGUE.instantiate()
			window.visible = false
			Globals.menu_container.add_child(window)

	return window


func play_sequence(sequence: DialogueSequence, ignore_setting: bool = false, no_anim: bool = false, string_format: Variant = {}) -> RunningDialogue:
	if !GameSettings.get_setting("SCAG_DIALOG", true) and !ignore_setting:
		return

	var runner = RunningDialogue.new(sequence, no_anim, string_format)
	runner.call_deferred("run")

	return runner

func load_sequence_from_path(file_path: String) -> Variant:
	if file_path.contains(".tres"):

		if file_path.contains(".remap"):
			file_path = file_path.replace(".remap", "")
		var dialogue_sequence = load(file_path)
		return dialogue_sequence
	return null

func get_all_sequences(root_path: String = "res://resources/dialogue/") -> Array[String]:
	var files = _get_sequences_recursive(root_path)

	return files

func _get_sequences_recursive(root_path: String) -> Array[String]:
	var found_files: Array[String] = []
	for path in ResourceLoader.list_directory(root_path):
		if path.ends_with("/"):
			var folder_path = root_path + path

			found_files.append_array(_get_sequences_recursive(folder_path))
		else:

			found_files.append(root_path + path)

	return found_files
