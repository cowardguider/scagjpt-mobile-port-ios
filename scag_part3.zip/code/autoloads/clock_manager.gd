extends Node





const DAY_SECONDS = 86400

var last_tab: String
var last_button: String
var weekday_names = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]

var alarm_storage: Array[Alarm] = []

var stopwatch_elapsed: float = 0
var stopwatch_lap_storage: Array[float] = []
var stopwatch_running: bool = false

var pomo_current_type: PomoType = PomoType.POMO
var pomo_elapsed: float = 0.0
var pomo_running: bool = false

enum PomoType{POMO, BREAK, LONG_BREAK}
enum Convention{AM = 0, PM = 1}
enum Weekday{Sunday = 0, Monday = 1, Tuesday = 2, Wednesday = 3, Thursday = 4, Friday = 5, Saturday = 6}

signal on_alarm_ring(alarm: Alarm)
signal on_pomo_ring(type: PomoType)


func is_using_24_hour_format() -> bool:
	return false

func utc_unix_to_local_unix(unix: float) -> float:
	var time_zone = Time.get_time_zone_from_system()
	var local_unix_time = unix + time_zone.bias * 60

	return local_unix_time

func local_unix_to_utc_unix(local_unix: float) -> float:
	var time_zone = Time.get_time_zone_from_system()
	var unix_time = local_unix - time_zone.bias * 60

	return unix_time

func get_weekday_string_from_enum(weekday: Weekday) -> String:
	return weekday_names[weekday]

func get_next_weekday(current_weekday: Weekday, weekday_list: Array[Weekday]) -> Weekday:
	weekday_list.sort()
	var weekdays_after = weekday_list.filter( func(weekday): return current_weekday < weekday)

	return weekdays_after.front() if weekdays_after.size() > 0 else weekday_list.front()


func get_next_local_ring_time_from_weekdays(_local_ring_unix: float, ring_every_list: Array[Weekday], weekday_offset: int = 0) -> float:
	var actual_local_ring_unix = int(_local_ring_unix) + DAY_SECONDS * weekday_offset
	var local_ring_date_dict = Time.get_datetime_dict_from_unix_time(actual_local_ring_unix)
	var current_weekday = local_ring_date_dict.weekday
	var next_weekday = get_next_weekday(current_weekday as ClockManager.Weekday, ring_every_list) as int
	var local_unix_now = utc_unix_to_local_unix(Time.get_unix_time_from_system())




	var day_multiple = 0
	for i in range(7 + abs(weekday_offset)):
		day_multiple += 1
		current_weekday = posmod(current_weekday + 1, 7)



		if current_weekday == next_weekday:


			if local_unix_now > actual_local_ring_unix + DAY_SECONDS * day_multiple:
				next_weekday = get_next_weekday(current_weekday as ClockManager.Weekday, ring_every_list) as int

				continue

			break

	return actual_local_ring_unix + DAY_SECONDS * day_multiple


func start_stopwatch() -> void :
	stopwatch_running = true



func stop_stopwatch() -> void :
	stopwatch_running = false

func reset_stopwatch() -> void :
	stopwatch_elapsed = 0
	stopwatch_lap_storage.clear()

func lap() -> Array:
	var elapsed = stopwatch_elapsed
	stopwatch_lap_storage.append(elapsed)
	save_stopwatch_data()
	return [stopwatch_lap_storage.size(), elapsed]

func load_stopwatch_data() -> void :
	stopwatch_elapsed = UserConfig.get_value("clock", "stopwatch_elapsed", 0)
	stopwatch_lap_storage.assign(UserConfig.get_value("clock", "stopwatch_laps", []))

func save_stopwatch_data() -> void :
	UserConfig.set_value("clock", "stopwatch_laps", stopwatch_lap_storage)
	UserConfig.set_value("clock", "stopwatch_elapsed", stopwatch_elapsed)
	UserConfig.save_to_file()




class Alarm:

	var name: String = ""
	var enabled: bool = true:
		set(new_value):
			if enabled != new_value:
				enabled = new_value
				on_enable_disable.emit(new_value)
	var convention: Convention = Convention.AM
	var target_ring_unix_time: float = 0
	var target_ring_hour_minute: Array[int] = [0, 0]
	var ring_every_list: Array[Weekday] = []
	signal on_enable_disable(is_enabled: bool)

	func _init(data: Dictionary = {}) -> void :
		if !data.is_empty():
			name = data.name if data.name is String else ""
			enabled = data.enabled if data.enabled is bool else false
			target_ring_unix_time = data.unix if data.unix is float else Time.get_unix_time_from_system() + 3600 * 2
			ring_every_list = data.weekdays if data.weekdays is Array[int] else []

			var ring_date_dict = Time.get_datetime_dict_from_unix_time(int(target_ring_unix_time))
			target_ring_hour_minute[0] = ring_date_dict.hour
			target_ring_hour_minute[1] = ring_date_dict.minute


			var local_ring_date_dict = Time.get_datetime_dict_from_unix_time(int(ClockManager.utc_unix_to_local_unix(target_ring_unix_time)))
			if local_ring_date_dict.hour >= 12:
				convention = Convention.PM
		else:

			var date_now_dict = Time.get_datetime_dict_from_system(true)
			date_now_dict.minute = 0
			date_now_dict.second = 0
			var date_ring_unix = Time.get_unix_time_from_datetime_dict(date_now_dict)
			date_ring_unix += 3600 * 2
			target_ring_unix_time = date_ring_unix

			var ring_date_dict = Time.get_datetime_dict_from_unix_time(int(date_ring_unix))
			target_ring_hour_minute[0] = ring_date_dict.hour
			target_ring_hour_minute[1] = ring_date_dict.minute


			var local_ring_date_dict = Time.get_datetime_dict_from_unix_time(int(ClockManager.utc_unix_to_local_unix(date_ring_unix)))
			if local_ring_date_dict.hour >= 12:
				convention = Convention.PM























	func get_local_hour_and_minute() -> Array[int]:
		var local_ring_unix_time = ClockManager.utc_unix_to_local_unix(target_ring_unix_time)
		var local_ring_datetime = Time.get_datetime_dict_from_unix_time(local_ring_unix_time)






		var hour_minute: Array[int] = [local_ring_datetime.hour, local_ring_datetime.minute]
		return hour_minute

	func apply_local_hour_and_minute_to_ring_time(hour_minute: Array[int]) -> void :

		print("[ClockManager]: applying %s to ring time" % [hour_minute])
		var local_date_now_dict = Time.get_datetime_dict_from_system()
		local_date_now_dict.hour = hour_minute[0]
		local_date_now_dict.minute = hour_minute[1]
		local_date_now_dict.second = 0
		var _local_ring_unix = Time.get_unix_time_from_datetime_dict(local_date_now_dict)
		var ring_unix_time: float = ClockManager.local_unix_to_utc_unix(_local_ring_unix)
		var now_unix_time = Time.get_unix_time_from_system()

		if ring_every_list.size() > 0:
			var next_ring_time = ClockManager.get_next_local_ring_time_from_weekdays(_local_ring_unix, ring_every_list, -1)
			ring_unix_time = ClockManager.local_unix_to_utc_unix(next_ring_time)
		else:

			if now_unix_time > ring_unix_time:

				ring_unix_time += 86400





		target_ring_unix_time = ring_unix_time
		var ring_date_dict = Time.get_datetime_dict_from_unix_time(int(ring_unix_time))
		target_ring_hour_minute[0] = ring_date_dict.hour
		target_ring_hour_minute[1] = ring_date_dict.minute
		ClockManager.save_alarm_data()

		print("This alarm will now ring at %s" % Time.get_datetime_string_from_unix_time(ClockManager.utc_unix_to_local_unix(target_ring_unix_time) as int, true))
		print("Global ring time: %s" % Time.get_datetime_string_from_unix_time(target_ring_unix_time as int, true))
		print("Current Time:    ", Time.get_datetime_dict_from_system(true))
		print("Local Time:      ", Time.get_datetime_dict_from_system())
		print("Ring Time:       ", Time.get_datetime_dict_from_unix_time(int(ring_unix_time)))
		print("Local Ring Time: ", Time.get_datetime_dict_from_unix_time(int(ClockManager.utc_unix_to_local_unix(ring_unix_time))))



func add_alarm(alarm: Alarm) -> void :
	alarm_storage.append(alarm)
	save_alarm_data()

func get_alarms() -> Array[Alarm]:
	return alarm_storage

func remove_alarm(alarm: Alarm) -> void :
	var index = alarm_storage.find(alarm)
	if index != -1:
		alarm_storage.remove_at(index)
	save_alarm_data()


func save_alarm_data() -> void :
	var save_data = []
	for alarm in alarm_storage:
		var data = {}
		data.name = alarm.name
		data.enabled = alarm.enabled
		data.unix = alarm.target_ring_unix_time
		data.weekdays = alarm.ring_every_list
		save_data.append(data)
	UserConfig.set_value("clock", "alarms", save_data)
	UserConfig.save_to_file()

func load_alarm_data() -> void :
	var save_data = UserConfig.get_value("clock", "alarms", [])
	for data in save_data:
		var alarm = Alarm.new(data)
		alarm_storage.append(alarm)



func start_pomo() -> void :
	pomo_running = true

func stop_pomo() -> void :
	pomo_running = false

func switch_pomo_type(type: PomoType) -> void :
	stop_pomo()
	pomo_current_type = type
	match type:
		PomoType.POMO:
			pomo_elapsed = 25 * 60
		PomoType.BREAK:
			pomo_elapsed = 5 * 60
		PomoType.LONG_BREAK:
			pomo_elapsed = 15 * 60














func _ready() -> void :
	load_stopwatch_data()
	load_alarm_data()

func _process(delta: float) -> void :
	for alarm in alarm_storage:
		if !alarm.enabled: continue












		if alarm.target_ring_unix_time < Time.get_unix_time_from_system():
			if alarm.ring_every_list.size() > 0:
				var local_ring_unix = utc_unix_to_local_unix(alarm.target_ring_unix_time) as int
				var next_ring_time = get_next_local_ring_time_from_weekdays(local_ring_unix, alarm.ring_every_list)
				alarm.target_ring_unix_time = local_unix_to_utc_unix(next_ring_time)
			else:
				alarm.enabled = false

			print("ALARM ALARM ALARM")
			ClockManager.save_alarm_data()
			on_alarm_ring.emit(alarm)

	if stopwatch_running:
		stopwatch_elapsed += delta

	if pomo_running:
		pomo_elapsed = maxf(pomo_elapsed - delta, 0)
		if pomo_elapsed == 0:
			stop_pomo()
			on_pomo_ring.emit(pomo_current_type)
