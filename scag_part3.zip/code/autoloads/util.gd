extends Node

func wait(time: float) -> void :
	await get_tree().create_timer(time).timeout

func debug_print(string: String):
	if OS.is_debug_build(): print(string)

func wait_screen_refresh() -> void :
	await get_tree().process_frame
	await get_tree().process_frame


func get_mouse_position() -> Vector2i:
	return DisplayServer.mouse_get_position() - DisplayServer.window_get_position()


func get_node_aabb(node: Node, exclude_top_level_transform: bool = true) -> AABB:
	var bounds: AABB = AABB()


	if node.is_queued_for_deletion() or node is Light3D:
		return bounds


	if node is VisualInstance3D:
		bounds = node.get_aabb();


	for child in node.get_children():
		var child_bounds: AABB = get_node_aabb(child, false)
		if bounds.size == Vector3.ZERO:
			bounds = child_bounds
		else:
			bounds = bounds.merge(child_bounds)

	if !exclude_top_level_transform and node is VisualInstance3D:
		bounds = node.transform * bounds

	return bounds



func get_bounding_size_of_all_screens() -> Vector2i:
	var bounds_x = 0
	var bounds_y = 0

	if Engine.is_embedded_in_editor():
		var size = get_tree().root.size
		bounds_x = size.x
		bounds_y = size.y
	else:
		for i in range(DisplayServer.get_screen_count()):
			var screen_size = DisplayServer.screen_get_size(i)
			var screen_pos = DisplayServer.screen_get_position(i)
			bounds_x = maxi(screen_pos.x + screen_size.x, bounds_x)
			bounds_y = maxi(screen_pos.y + screen_size.y, bounds_y)

	return Vector2i(bounds_x, bounds_y)


func get_current_screen() -> int:
	return ScreenBounds.current_screen












func clamp_to_all_screen_size(vector: Vector2i) -> Vector2i:
	var total_size = get_bounding_size_of_all_screens()
	Debugger.write("Total Screen Size: {0}".format([total_size]), "TotalScreenSize")

	return Vector2i(
		clampi(vector.x, 0, total_size.x), 
		clampi(vector.y, 0, total_size.y)
	)


func clamp_to_target_screen_size(screen: int, vector: Vector2i, clamp_whole_window: bool = false) -> Vector2i:
	var screen_size: Vector2i
	var screen_position: Vector2i
	var offset: Vector2i = Vector2i.ZERO

	if OS.has_feature("linux") or OS.has_feature("macos"):
		var screen_bounds = DisplayServer.screen_get_usable_rect(screen)
		screen_size = screen_bounds.size
		screen_position = screen_bounds.position
	else:
		screen_size = DisplayServer.screen_get_size(screen)
		screen_position = DisplayServer.screen_get_position(screen)


	if clamp_whole_window:
		var window_size = DisplayServer.window_get_size(0)
		if screen_position.x + screen_size.x > vector.x:
			offset.x = window_size.x


		if screen_position.y + screen_size.y > vector.y:
			offset.y = window_size.y

	Debugger.write("Clamp offset: %s" % offset, "clampoffset", 10)
	Debugger.write("vectore %s" % vector, "clampvect", 10)

	return Vector2i(
		clampi(vector.x, screen_position.x, screen_size.x + screen_position.x - offset.x), 
		clampi(vector.y, screen_position.y, screen_size.y + screen_position.y - offset.y)
	)





func clamp_to_window_size(vector: Vector2, clamp_offset: Vector2 = Vector2.ZERO) -> Vector2:
	var window_size = get_tree().root.size




	return Vector2(
		clampf(vector.x, 0, window_size.x + clamp_offset.x), 
		clampf(vector.y, 0, window_size.y + clamp_offset.y)
	)


func icbin_tweenService(object, what, target, tweenTime, easingStyle, easingDirection) -> Tween:
	var tween = create_tween()
	tween.set_trans(easingStyle)
	tween.set_ease(easingDirection)
	tween.tween_property(object, what, target, tweenTime)
	return tween



func posmodoff(x: int, y: int) -> int:
	return posmod(x - 1, y) + 1


func random_bool() -> bool:
	return randi_range(0, 1) == 1

func format_number_with_dots(number: int) -> String:
	var num_str: String = str(abs(number))
	var result: String = ""
	var count: int = 0

	for i in range(num_str.length() - 1, -1, -1):
		result = num_str[i] + result
		count += 1
		if count % 3 == 0 and i != 0:
			result = "," + result

	if number < 0:
		result = "-" + result

	return result

var _arguments: Dictionary[String, String]
func get_cmdline_args_formatted() -> Dictionary[String, String]:
	var arguments: Dictionary[String, String] = {}

	if !_arguments:
		for argument in OS.get_cmdline_args():
			if argument.contains("="):
				var key_value = argument.split("=")
				arguments[key_value[0].trim_prefix("--")] = key_value[1]
			else:


				arguments[argument.trim_prefix("--")] = ""

		_arguments = arguments
	else:
		arguments = _arguments

	print("args: ", arguments)
	return arguments


func tr_key_exists(translation_key: String) -> bool:
	var str: String = tr(translation_key)

	return str != translation_key
