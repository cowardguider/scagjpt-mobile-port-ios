extends Node




const CHARACTER_SCALE_MIN = 0.1
const CHARACTER_SCALE_MAX = 0.32
const DEFAULT_WINDOW_SIZE = Vector2i(750, 750)


var DEBUG_COVER_SCREEN = false
var character: CharacterWorker
var menu_container: SubViewport
var face_menu: FaceMenu
var gui_3d: GUI3D
var screen_collision: ScreenCollision
var camera: CharacterCamera
var tutorial: _Tutorial

var is_game_closing: bool = false
var is_media_player_showing: bool = false
var menu_mode_toggle_disabled: PriorityManager = PriorityManager.new(false)
var menu_mode_input_disabled: PriorityManager = PriorityManager.new(false)
var poke_enabled: PriorityManager = PriorityManager.new(true)
var drag_enabled: PriorityManager = PriorityManager.new(true)
var media_player_loading_enabled: PriorityManager = PriorityManager.new(true)

var ragebait: float = -999.0







func _ready() -> void :
	print("[globals.gd]: OS Name: ", OS.get_name())
	print("[globals.gd]: Processor: ", OS.get_processor_name())
	print("[globals.gd]: Memory Info (RAM): ", OS.get_memory_info())
	print("[globals.gd]: GPU Adapter: ", RenderingServer.get_video_adapter_name())
	print("[globals.gd]: GPU Vendor: ", RenderingServer.get_video_adapter_vendor())
	TranslationServer.set_locale("en")
