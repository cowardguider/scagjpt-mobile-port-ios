extends Node
# iOS port: Steam removed. Same public API, no Steamworks calls.

const DEFAULT_PFP = preload("uid://cq7x6pkq3lwjf")
signal on_steam_initialized()
var initialized = false
var last_known_username: String = "Randall Moss"

func wait_until_init() -> void:
	pass

func get_username() -> String:
	return UserConfig.get_value("steam", "username", last_known_username)

func get_profile_pic() -> Texture2D:
	return DEFAULT_PFP
