extends Node
















enum SettingMSAA{
	SETTING_ENUM_MSAA_DISABLED, 
	SETTING_ENUM_MSAA_X2, 
	SETTING_ENUM_MSAA_X4, 
	SETTING_ENUM_MSAA_X8
}

enum SettingSSAA{
	SETTING_ENUM_SSAA_DISABLED, 
	SETTING_ENUM_SSAA_FXAA, 
	SETTING_ENUM_SSAA_SMAA, 
}

enum SettingRenderMethod{
	SETTING_ENUM_RENDER_METHOD_FORWARD, 
	SETTING_ENUM_RENDER_METHOD_MOBILE, 

}

var render_method_names = ["forward_plus", "mobile", "gl_compatibility"]

var volume_translation = {
	VOLUME_MASTER = "Master", 
	VOLUME_SFX = "SFX", 
	VOLUME_VOICE = "Voice", 
	VOLUME_MUSIC = "Music", 
	VOLUME_UI = "UI", 
	VOLUME_RINGTONE = "Ringtone", 
}

var ClassedSettings: Array[SettingData] = [
	SettingDataBoolean.new(default_setting_callback, 0, "SCAG_DIALOG", true), 
	SettingDataBoolean.new( func(_key, value: bool):
		if Globals.character:
			Globals.character.roaming_enabled = value
		, 0, "SCAG_ROAMING", false), 
	SettingDataBoolean.new(default_setting_callback, 0, "INTRO_SCREEN_ENABLED", true), 
	SettingDataBoolean.new(default_setting_callback, 0, "READ_ROBLOX_LOG_FILES", true), 
	SettingDataBoolean.new(default_setting_callback, 0, "READ_STUDIO_OVER_PLAYER", false), 
	SettingDataBoolean.new(default_setting_callback, 0, "QUICK_TUTORIAL", true), 

	SettingDataSlider.new( func(_key: String, value: float): RenderingServer.viewport_set_scaling_3d_scale(get_viewport().get_viewport_rid(), value), 
	1, "RENDERING_SCALING_3D", ProjectSettings.get_setting_with_override("rendering/scaling_3d/scale") as float, 0.5, 2.0, 0.1), 
	SettingDataEnum.new( func(_key: String, value: RenderingServer.ViewportMSAA): RenderingServer.viewport_set_msaa_3d(get_viewport().get_viewport_rid(), value), 
		1, Array(SettingMSAA.keys(), TYPE_STRING, &"", null), ProjectSettings.get_setting_with_override("rendering/anti_aliasing/quality/msaa_3d") as int, "RENDERING_MSAA"), 
	SettingDataEnum.new( func(_key: String, value: RenderingServer.ViewportScreenSpaceAA): RenderingServer.viewport_set_screen_space_aa(get_viewport().get_viewport_rid(), value), 
		1, Array(SettingSSAA.keys(), TYPE_STRING, &"", null), ProjectSettings.get_setting_with_override("rendering/anti_aliasing/quality/screen_space_aa") as int, "RENDERING_SS_AA"), 
	SettingDataEnum.new(rendering_method_callback, 1, Array(SettingRenderMethod.keys(), TYPE_STRING, &"", null), ProjectSettings.get_setting_with_override("rendering/renderer/rendering_method") as int, "RENDERING_METHOD"), 
	SettingDataBoolean.new(default_setting_callback, 1, "CRT_EFFECT", true), 

	SettingDataSlider.new(change_volume_callback, 2, "VOLUME_MASTER", 0.5, 0.0, 1.0, 0.1), 
	SettingDataSlider.new(change_volume_callback, 2, "VOLUME_SFX", 1.0, 0.0, 1.0, 0.1), 
	SettingDataSlider.new(change_volume_callback, 2, "VOLUME_VOICE", 1.0, 0.0, 1.0, 0.1), 
	SettingDataSlider.new(change_volume_callback, 2, "VOLUME_MUSIC", 1.0, 0.0, 1.0, 0.1), 
	SettingDataSlider.new(change_volume_callback, 2, "VOLUME_RINGTONE", 1.0, 0.0, 1.0, 0.1), 
	SettingDataSlider.new(change_volume_callback, 2, "VOLUME_UI", 1.0, 0.0, 1.0, 0.1), 
]

var _dict_settings = {}
signal on_setting_changed(key: String, new_value: Variant)

func _ready() -> void :


	print("Let's apply these settings!")

	for setting: SettingData in ClassedSettings:
		_dict_settings.set(setting.id, setting)

		var id = setting.id
		if setting is SettingDataBoolean:
			var existing = get_setting(id, setting.boolean_default)
			setting.value = existing
			set_setting(setting.id, existing)
		elif setting is SettingDataSlider:
			var existing = get_setting(id, setting.slider_default)
			setting.value = existing
			set_setting(setting.id, existing)
		elif setting is SettingDataEnum:
			var existing = get_setting(id, setting.enum_default)
			setting.value = existing
			set_setting(setting.id, existing)

		setting.callable.call(setting.id, setting.value)
		print("[game_settings.gd]: Setting %s to %s" % [setting.id, setting.value])






func rendering_method_callback(_key: String, value: Variant):

	var new_rendering_method = render_method_names[value as int]
	if RenderingServer.get_current_rendering_method() != new_rendering_method:
		var target_rendering_driver = "d3d12"
		var restart_params = ["--rendering-method", new_rendering_method]
		if OS.has_feature("windows"):
			target_rendering_driver = RenderingServer.get_current_rendering_driver_name()
		elif OS.has_feature("linuxbsd"):
			target_rendering_driver = "vulkan"
		print("[game_settings.gd]: Rendering driver: %s" % target_rendering_driver)

		restart_params.append("--rendering-driver")
		restart_params.append(target_rendering_driver)
		if Globals.character:
			var popup_instance: PackedScene = load("uid://c87kix6fiqilg")
			var popup = popup_instance.instantiate()
			Globals.menu_container.add_child(popup)
			var confirmed = await popup.on_confirmation

			if confirmed:
				print("RESTARTING...")
				if OS.has_feature("editor_hint") or OS.has_feature("editor_runtime"): return
				Globals.is_game_closing = true
				restart_params.append("--no_intro=true")
				OS.set_restart_on_exit(true, restart_params)
				get_tree().quit()
		else:
			if OS.has_feature("editor_hint") or OS.has_feature("editor_runtime"): return
			Globals.is_game_closing = true
			OS.set_restart_on_exit(true, restart_params)
			get_tree().quit()


func default_setting_callback(key: String, value: Variant):
	print("Function %s called: %s" % [key, var_to_str(value)])

func change_volume_callback(group: String, value: float):
	var group_key = volume_translation[group]
	var bus_index = AudioServer.get_bus_index(group_key)
	if value <= 0.0:
		AudioServer.set_bus_mute(bus_index, true)
	else:
		AudioServer.set_bus_mute(bus_index, false)
		AudioServer.set_bus_volume_db(bus_index, linear_to_db(value))
	print("Volume change group %s called: %s" % [group, value])



func set_setting_and_update(key: String, value: Variant) -> void :
	set_setting(key, value)
	var setting: SettingData = _dict_settings.get(key)
	setting.callable.call(key, value)
	setting.value = value

func set_setting(key: String, value: Variant) -> void :
	UserConfig.set_value("settings", key, value)
	UserConfig.save_to_file()
	on_setting_changed.emit(key, value)

func get_setting(key: String, default: Variant) -> Variant:
	return UserConfig.get_value("settings", key, default)
