extends Node


const USER_CONFIG_PATH = "user://preferences.cfg"
const DEV_USER_CONFIG_PATH = "user://preferences_dev.cfg"

var config: ConfigFile
var target_path: String

func _migrate_data():
	var prev_version = get_value("game", "version", "")
	var version = ProjectSettings.get_setting_with_override("application/config/version")





	if prev_version != version:
		print("[user_config.gd]: Migrating data to latest version...")

		if get_value("settings", "RENDERING_METHOD", 0) == 2:
			set_value("settings", "RENDERING_METHOD", 1)


	set_value("game", "version", version)

func _init() -> void :

	target_path = DEV_USER_CONFIG_PATH if OS.has_feature("editor") else USER_CONFIG_PATH
	config = load_from_file()
	_migrate_data()
	if !config:
		push_error("Could not load user configuration")
	else:
		print("Successfully loaded data!")
		print(config.encode_to_text())

func _notification(what: int) -> void :


	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		save_to_file()
		get_tree().quit()



func set_value(section: String, key: String, value: Variant) -> void :
	Util.debug_print("[user_config.gd]: Set: %s %s %s" % [section, key, str(value)])
	config.set_value(section, key, value)

func get_value(section: String, key: String, default: Variant) -> Variant:
	Util.debug_print("[user_config.gd]: Get: %s %s %s" % [section, key, str(default)])
	return config.get_value(section, key, default)



func load_from_file() -> ConfigFile:
	var file = ConfigFile.new()

	if FileAccess.file_exists(target_path):
		var err = file.load(target_path)
		if err != OK:
			push_error(err)

	return file

func save_to_file() -> void :
	var error = config.save(target_path)
	if error != OK:
		push_error("Could not save user configuration file: %s" % str(error))
