class_name PriorityManager

var priorities: Dictionary[int, Variant] = {}
var highest_priority: int = -1
var _highest_priority_value: Variant
signal priority_changed(value: Variant, priority: float)

func _init(defaultValue: Variant) -> void :
	priorities[-1] = defaultValue

func _on_changed() -> void :
	var new_highest_priority = priorities.keys().max()

	if new_highest_priority != highest_priority or new_highest_priority == highest_priority and (_highest_priority_value != get_prioritized_value()):
		highest_priority = new_highest_priority
		var value = get_prioritized_value()
		_highest_priority_value = value
		priority_changed.emit(value, new_highest_priority)



func add(priority: int, value: Variant) -> void :
	priorities[priority] = value
	_on_changed()

func remove(priority: int) -> void :
	priorities.erase(priority)
	_on_changed()

func get_prioritized_value() -> Variant:
	return priorities.get(highest_priority)
