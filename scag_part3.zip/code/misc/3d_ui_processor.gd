class_name GUI3D extends Node3D

@export var viewport: SubViewport
@export var quad_mesh: MeshInstance3D
@export var area: Area3D


var last_event_pos2D = null

var last_event_time: float = -1.0

var is_mouse_inside: bool = false
var pressed_block: bool = false
var last_mouse_button: InputEventMouseButton

signal on_input_event(event: InputEvent)


func _ready() -> void :
	Globals.gui_3d = self
	area.mouse_entered.connect(_mouse_entered_area)
	area.mouse_exited.connect(_mouse_exited_area)
	area.input_event.connect(_mouse_input_event)
	process_priority = 1

func _mouse_entered_area():
	is_mouse_inside = true


func _mouse_exited_area():
	is_mouse_inside = false

	if last_mouse_button and last_mouse_button.pressed:
		last_mouse_button.pressed = false
		viewport.push_input(last_mouse_button)
		viewport.push_unhandled_input(last_mouse_button)
		last_mouse_button = null


func _unhandled_input(event):

	for mouse_event in [InputEventMouseButton, InputEventMouseMotion, InputEventScreenDrag, InputEventScreenTouch]:
		if is_instance_of(event, mouse_event):


			return
	if !Globals.menu_mode_input_disabled.get_prioritized_value():
		viewport.push_input(event)




func _input(event: InputEvent) -> void :
	if event is InputEventMouseButton:
		if event.pressed and is_mouse_inside and !Globals.menu_mode_input_disabled.get_prioritized_value():
			pressed_block = true

		else:

			pressed_block = false


func _mouse_input_event(_camera: Camera3D, event: InputEvent, event_position: Vector3, _normal: Vector3, _shape_idx: int):

	var quad_mesh_size = quad_mesh.mesh.size


	var event_pos3D = event_position


	var now: float = Time.get_ticks_msec() / 1000.0



	event_pos3D = quad_mesh.global_transform.affine_inverse() * event_pos3D

	var event_pos2D: Vector2 = Vector2()

	if is_mouse_inside:

		event_pos2D = Vector2(event_pos3D.x, event_pos3D.z)



		event_pos2D.x = event_pos2D.x / quad_mesh_size.x
		event_pos2D.y = event_pos2D.y / quad_mesh_size.y

		event_pos2D.x += 0.5
		event_pos2D.y += 0.5


		event_pos2D.x *= viewport.size.x
		event_pos2D.y *= viewport.size.y


	elif last_event_pos2D != null:

		event_pos2D = last_event_pos2D


	event.position = event_pos2D
	if event is InputEventMouse:
		event.global_position = event_pos2D


	if event is InputEventMouseMotion or event is InputEventScreenDrag:

		if last_event_pos2D == null:
			event.relative = Vector2(0, 0)


		else:
			event.relative = event_pos2D - last_event_pos2D
			event.velocity = event.relative / (now - last_event_time)


	last_event_pos2D = event_pos2D


	last_event_time = now


	if !Globals.menu_mode_input_disabled.get_prioritized_value():
		if event is InputEventMouseButton:
			last_mouse_button = event

		viewport.push_input(event)
		viewport.push_unhandled_input(event)
		on_input_event.emit(event)
