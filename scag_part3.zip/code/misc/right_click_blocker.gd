extends LineEdit

var is_menu_showing: bool = false
var context_menu: PopupMenu

func _ready() -> void :
	context_menu = get_menu()
	context_menu.visibility_changed.connect(_on_context_menu_visibility_changed)

func _on_context_menu_visibility_changed() -> void :
	if context_menu.visible:
		Globals.menu_mode_toggle_disabled.add(1, true)
	else:
		Globals.menu_mode_toggle_disabled.remove(1)

func _on_mouse_entered() -> void :
	Globals.menu_mode_toggle_disabled.add(0, true)

func _on_mouse_exited() -> void :
	Globals.menu_mode_toggle_disabled.remove(0)

func _exit_tree() -> void :
	Globals.menu_mode_toggle_disabled.remove(0)
	Globals.menu_mode_toggle_disabled.remove(1)
