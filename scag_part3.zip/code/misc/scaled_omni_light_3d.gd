@tool
class_name ScaledOmniLight3D extends OmniLight3D

@export_range(0, 10, 0.001, "prefer_slider") var target_range: float = 1.0

func _process(_delta: float) -> void :
	var parent = get_parent_node_3d()
	if parent == null: return
	var gubby_scale = parent.global_basis.get_scale()
	omni_range = target_range * gubby_scale.y
